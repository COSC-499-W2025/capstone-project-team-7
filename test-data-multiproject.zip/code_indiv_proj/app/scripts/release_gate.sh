#!/usr/bin/env bash
set -euo pipefail

PROJECT_PATH=${PROJECT_PATH:-"wordoku/wordoku.xcodeproj"}
SCHEME=${SCHEME:-"wordoku"}
DESTINATION=${DESTINATION:-"platform=iOS Simulator,name=iPhone 17"}

xcodebuild -project "$PROJECT_PATH" -scheme "$SCHEME" -configuration Debug -destination "$DESTINATION" build
xcodebuild -project "$PROJECT_PATH" -scheme "$SCHEME" -destination "$DESTINATION" test

printf "\nRelease gate build+tests passed.\n"
printf "Run manual smoke checks: normal levels, daily challenge input/render, settings toggles, save/restore timer.\n"
