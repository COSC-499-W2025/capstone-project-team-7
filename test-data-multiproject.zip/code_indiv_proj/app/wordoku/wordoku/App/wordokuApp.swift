import SwiftUI
@main
struct WordokuApp: App {
    init() {
        if ProcessInfo.processInfo.arguments.contains("-ui-testing-reset") {
            let defaults = UserDefaults.standard
            for key in defaults.dictionaryRepresentation().keys {
                defaults.removeObject(forKey: key)
            }
        }
    }

    var body: some Scene {
        WindowGroup {
            MainMenuView()
                .tint(WordokuTheme.accentBlue)
        }
    }
}
