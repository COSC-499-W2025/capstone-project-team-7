import SwiftUI
import Combine

struct GameView: View {
    @StateObject private var viewModel: GameViewModel
    @AppStorage("settings.showMistakes") private var showMistakes = true
    @AppStorage("settings.penaltyMode") private var penaltyModeEnabled = false
    @AppStorage("settings.showConflicts") private var showConflicts = true
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    let levelNumber: Int
    let difficulty: Difficulty
    let onComplete: () -> Void
    let onStatePersisted: () -> Void
    @State private var didNotify = false
    @State private var showWordIntro = false
    @State private var wordIntroVisible = false
    @State private var hasRevealedWordMeaning = false
    @State private var didAutoShowWordMeaning = false
    @State private var showCompletionPopup = false
    @State private var completionTime: TimeInterval = 0
    @State private var personalBestTime: TimeInterval?
    @State private var isNewBest = false
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase

    init(
        level: WordokuLevel,
        levelNumber: Int,
        difficulty: Difficulty,
        savedState: SavedGameState? = nil,
        onComplete: @escaping () -> Void = {},
        onStatePersisted: @escaping () -> Void = {}
    ) {
        let vm = GameViewModel(level: level)
        if let saved = savedState {
            vm.restoreState(from: saved)
        }
        _viewModel = StateObject(wrappedValue: vm)
        self.levelNumber = levelNumber
        self.difficulty = difficulty
        self.onComplete = onComplete
        self.onStatePersisted = onStatePersisted
    }

    private var isWordRevealed: Bool {
        hasRevealedWordMeaning || viewModel.isWordComplete || viewModel.isComplete
    }

    var body: some View {
        ZStack(alignment: .top) {
            ScrollView {
                VStack(spacing: WordokuTheme.spacingL) {
                    GameHeader(
                        word: viewModel.level.word.raw,
                        isWordRevealed: isWordRevealed,
                        levelNumber: levelNumber,
                        elapsedTime: viewModel.elapsedTime,
                        mistakeCount: viewModel.mistakeCount,
                        showMistakes: showMistakes,
                        penaltyModeEnabled: penaltyModeEnabled
                    )
                    
                    GridView(
                        grid: viewModel.grid,
                        letters: viewModel.letters,
                        selectedIndex: viewModel.selectedIndex,
                        givenIndices: viewModel.givenIndices,
                        conflictIndices: viewModel.conflictIndices,
                        forcedIndices: viewModel.forcedIndices,
                        orderedForcedIndices: viewModel.orderedForcedIndices,
                        isComplete: viewModel.isComplete,
                        isWordComplete: viewModel.isWordComplete,
                        onSelect: { viewModel.select(index: $0) }
                    )
                    .aspectRatio(1, contentMode: .fit)
                    .padding(.horizontal, WordokuTheme.spacingM)

                    GameControls(
                        letters: viewModel.letters,
                        onSelectIndex: { viewModel.setValue($0) },
                        onDelete: { viewModel.setValue(nil) },
                        onLongDelete: { viewModel.undo() },
                        liquidGlassEnabled: liquidGlassEnabled
                    )

                    Spacer(minLength: WordokuTheme.spacingXL)
                }
                .padding(.top, WordokuTheme.spacingM)
            }
            .background(WordokuPaperBackground())

            if viewModel.isComplete {
                WinOverlayView(forcedWord: viewModel.level.word.raw)
                    .padding(.top, WordokuTheme.spacingM)
                    .transition(.opacity)
            }

            if showWordIntro {
                WordIntroOverlay(
                    word: viewModel.level.word.raw,
                    meaning: WordMeaningProvider.meaning(for: viewModel.level.word.raw),
                    isVisible: wordIntroVisible,
                    onDismiss: dismissWordIntro
                )
            }

            if showCompletionPopup {
                CompletionPopupOverlay(
                    word: viewModel.level.word.raw,
                    levelNumber: levelNumber,
                    completionTime: completionTime,
                    personalBestTime: personalBestTime,
                    isNewBest: isNewBest,
                    onDismiss: { dismiss() },
                    onContinue: { dismiss() }
                )
            }
        }
        .animation(.easeInOut(duration: 0.18), value: viewModel.isComplete)
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                HStack(spacing: 12) {
                    Button(action: { viewModel.undo() }) {
                        Image(systemName: "arrow.uturn.backward")
                            .foregroundColor(WordokuTheme.accentBlue)
                    }
                    .disabled(!viewModel.canUndo)
                    .opacity(viewModel.canUndo ? 1.0 : 0.3)
                    .accessibilityLabel("Undo")
                    
                    Button(action: { viewModel.redo() }) {
                        Image(systemName: "arrow.uturn.forward")
                            .foregroundColor(WordokuTheme.accentBlue)
                    }
                    .disabled(!viewModel.canRedo)
                    .opacity(viewModel.canRedo ? 1.0 : 0.3)
                    .accessibilityLabel("Redo")
                }
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                if viewModel.isComplete {
                    Button(action: { showDefinitionOverlay() }) {
                        Image(systemName: "book")
                            .foregroundColor(WordokuTheme.accentBlue)
                    }
                    .accessibilityLabel("Definition")
                }
            }
        }
        .onChange(of: viewModel.isComplete) { newValue in
            if newValue && !didNotify {
                didNotify = true
                completionTime = viewModel.elapsedTime
                let levelIndex = levelNumber - 1
                let previousBest = ProgressStore.loadPersonalBest(level: levelIndex, difficulty: difficulty)
                isNewBest = previousBest == nil || viewModel.elapsedTime < (previousBest ?? .infinity)
                ProgressStore.savePersonalBest(level: levelIndex, difficulty: difficulty, time: viewModel.elapsedTime)
                personalBestTime = ProgressStore.loadPersonalBest(level: levelIndex, difficulty: difficulty)
                onComplete()
                presentWordDefinitionAfterReveal()
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                        showCompletionPopup = true
                    }
                }
            }
        }
        .onAppear {
            viewModel.setPenaltyMode(penaltyModeEnabled)
            viewModel.showConflicts = showConflicts
        }
        .onChange(of: showConflicts) { enabled in
            viewModel.showConflicts = enabled
        }
        .onChange(of: penaltyModeEnabled) { enabled in
            viewModel.setPenaltyMode(enabled)
        }
        .onChange(of: viewModel.isWordComplete) { newValue in
            if newValue {
                presentWordDefinitionAfterReveal()
            }
        }
        .onChange(of: viewModel.grid.cells) { _ in
            saveProgressSnapshot()
        }
        .onChange(of: viewModel.mistakeCount) { _ in
            saveProgressSnapshot()
        }
        .onChange(of: scenePhase) { phase in
            if phase == .inactive || phase == .background {
                saveProgressSnapshot()
            }
        }
        .onReceive(Timer.publish(every: 1.0, on: .main, in: .common).autoconnect()) { _ in
            saveProgressSnapshot()
        }
        .onDisappear {
            saveProgressSnapshot()
            onStatePersisted()
        }
    }

    private func saveProgressSnapshot() {
        if viewModel.isComplete {
            GameViewModel.clearSavedState()
            return
        }
        viewModel.saveState(levelIndex: levelNumber - 1, difficulty: difficulty)
    }

    private func dismissWordIntro() {
        withAnimation(.easeInOut(duration: 0.25)) {
            wordIntroVisible = false
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
            showWordIntro = false
        }
    }

    private func showDefinitionOverlay() {
        hasRevealedWordMeaning = true
        showWordIntro = true
        withAnimation(.easeOut(duration: 0.4)) {
            wordIntroVisible = true
        }
    }

    private func presentWordDefinitionAfterReveal() {
        guard !didAutoShowWordMeaning else { return }
        didAutoShowWordMeaning = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
            showDefinitionOverlay()
        }
    }
}

// MARK: - Game Header

private struct GameHeader: View {
    let word: String
    let isWordRevealed: Bool
    let levelNumber: Int
    let elapsedTime: TimeInterval
    let mistakeCount: Int
    let showMistakes: Bool
    let penaltyModeEnabled: Bool

    private var displayedWord: String {
        if isWordRevealed {
            return word.uppercased()
        }
        return String(repeating: "•", count: word.count)
    }
    
    var body: some View {
        VStack(spacing: WordokuTheme.spacingS) {
            Text("LEVEL \(levelNumber)")
                .font(.caption.weight(.semibold))
                .foregroundColor(WordokuTheme.secondaryText)
                .tracking(1.2)
            
            Text(displayedWord)
                .font(.system(size: 32, weight: .bold, design: .serif))
                .tracking(6)
                .foregroundColor(WordokuTheme.titleColor)

            Text(formatTime(elapsedTime))
                .font(.system(size: 18, weight: .semibold, design: .monospaced))
                .foregroundColor(WordokuTheme.secondaryText)
                .accessibilityIdentifier("game_timer")

            if showMistakes {
                HStack(spacing: WordokuTheme.spacingXS) {
                    Text("Mistakes: \(mistakeCount)")
                        .font(.footnote.weight(.semibold))
                        .foregroundColor(mistakeCount == 0 ? WordokuTheme.secondaryText : WordokuTheme.accentInk)
                    if penaltyModeEnabled {
                        Text("(+15s each)")
                            .font(.footnote)
                            .foregroundColor(WordokuTheme.secondaryText)
                    }
                }
            }
        }
        .padding(.vertical, WordokuTheme.spacingS)
    }

    private func formatTime(_ seconds: TimeInterval) -> String {
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%d:%02d", mins, secs)
    }
}

// MARK: - Word Intro Overlay

private struct WordIntroOverlay: View {
    let word: String
    let meaning: String
    let isVisible: Bool
    let onDismiss: () -> Void

    @State private var showWord = false
    @State private var showMeaning = false
    @State private var showPrompt = false

    var body: some View {
        ZStack {
            WordokuPaperBackground()
                .overlay(Color.black.opacity(0.18).ignoresSafeArea())
                .onTapGesture { onDismiss() }

            VStack(spacing: 0) {
                Spacer(minLength: 0)

                VStack(spacing: WordokuTheme.spacingL) {
                    Text("Your Hidden Word")
                        .font(.caption.weight(.semibold))
                        .tracking(1.3)
                        .foregroundColor(WordokuTheme.secondaryText)
                        .opacity(showWord ? 1 : 0)

                    Text(word.uppercased())
                        .font(.system(size: 44, weight: .semibold, design: .serif))
                        .tracking(7)
                        .foregroundColor(WordokuTheme.primaryText)
                        .opacity(showWord ? 1 : 0)
                        .offset(y: showWord ? 0 : 10)

                    Text(meaning)
                        .font(.title3.weight(.regular))
                        .foregroundColor(WordokuTheme.secondaryText)
                        .multilineTextAlignment(.center)
                        .lineSpacing(6)
                        .padding(.horizontal, WordokuTheme.spacingXL)
                        .opacity(showMeaning ? 1 : 0)
                        .offset(y: showMeaning ? 0 : 12)

                    Text("Tap anywhere to begin")
                        .font(.footnote.weight(.medium))
                        .foregroundColor(WordokuTheme.secondaryText.opacity(0.9))
                        .padding(.top, WordokuTheme.spacingM)
                        .opacity(showPrompt ? 1 : 0)
                }

                Spacer(minLength: 0)
            }
            .padding(.vertical, WordokuTheme.spacingXL)
            .contentShape(Rectangle())
            .onTapGesture { onDismiss() }
        }
        .opacity(isVisible ? 1 : 0)
        .animation(.easeInOut(duration: 0.35), value: isVisible)
        .onChange(of: isVisible) { visible in
            if visible {
                runStagedReveal()
            }
        }
        .onAppear {
            if isVisible {
                runStagedReveal()
            }
        }
        .allowsHitTesting(isVisible)
    }

    private func runStagedReveal() {
        showWord = false
        showMeaning = false
        showPrompt = false

        withAnimation(.easeOut(duration: 0.45)) {
            showWord = true
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.28) {
            withAnimation(.easeOut(duration: 0.6)) {
                showMeaning = true
            }
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.75) {
            withAnimation(.easeOut(duration: 0.45)) {
                showPrompt = true
            }
        }
    }
}

// MARK: - Game Controls

private struct GameControls: View {
    let letters: [Character]
    let onSelectIndex: (Int) -> Void
    let onDelete: () -> Void
    let onLongDelete: () -> Void
    let liquidGlassEnabled: Bool
    
    var body: some View {
        VStack(spacing: WordokuTheme.spacingM) {
            LetterPaletteView(
                letters: letters,
                onSelect: onSelectIndex,
                onDelete: onDelete,
                onLongDelete: onLongDelete
            )
            .padding(.horizontal, WordokuTheme.spacingL)
        }
    }
}

// MARK: - Completion Popup Overlay

private struct CompletionPopupOverlay: View {
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    let word: String
    let levelNumber: Int
    let completionTime: TimeInterval
    let personalBestTime: TimeInterval?
    let isNewBest: Bool
    let onDismiss: () -> Void
    let onContinue: () -> Void
    @State private var isVisible = false

    var body: some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()
                .onTapGesture {
                    onDismiss()
                }

            VStack(spacing: WordokuTheme.spacingL) {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 56))
                    .foregroundColor(WordokuTheme.accentBlue)

                VStack(spacing: WordokuTheme.spacingS) {
                    Text("Level \(levelNumber) Complete!")
                        .font(.system(size: 24, weight: .bold, design: .serif))
                        .foregroundColor(WordokuTheme.primaryText)

                    Text("You found the word")
                        .font(.subheadline)
                        .foregroundColor(WordokuTheme.secondaryText)

                    Text(word.uppercased())
                        .font(.system(size: 28, weight: .semibold, design: .serif))
                        .tracking(4)
                        .foregroundColor(WordokuTheme.accentBlue)
                        .padding(.top, WordokuTheme.spacingXS)

                    Text("Time: \(formatTime(completionTime))")
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(WordokuTheme.primaryText)

                    if let personalBestTime {
                        HStack(spacing: WordokuTheme.spacingXS) {
                            Text("Best: \(formatTime(personalBestTime))")
                                .font(.footnote.weight(.medium))
                                .foregroundColor(WordokuTheme.secondaryText)
                            if isNewBest {
                                Text("New Best!")
                                    .font(.caption.weight(.bold))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 4)
                                    .background(
                                        Capsule()
                                            .fill(WordokuTheme.accentBlue)
                                    )
                            }
                        }
                    }
                }

                Button(action: onContinue) {
                    Text("Continue")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(WordokuTheme.accentBlue)
                        .cornerRadius(12)
                }
                .padding(.top, WordokuTheme.spacingS)
            }
            .padding(WordokuTheme.spacingXL)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))
                    .overlay(
                        RoundedRectangle(cornerRadius: 24)
                            .stroke(WordokuTheme.divider, lineWidth: WordokuTheme.borderWidth)
                    )
            )
            .shadow(color: Color.black.opacity(0.2), radius: 24, y: 12)
            .padding(WordokuTheme.spacingL)
            .opacity(isVisible ? 1 : 0)
            .scaleEffect(isVisible ? 1 : 0.9)
        }
        .onAppear {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
                isVisible = true
            }
        }
    }

    private func formatTime(_ seconds: TimeInterval) -> String {
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%d:%02d", mins, secs)
    }
}
