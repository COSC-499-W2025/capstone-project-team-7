import SwiftUI

struct SettingsView: View {
    @AppStorage("settings.sound") private var soundEnabled = true
    @AppStorage("settings.haptics") private var hapticsEnabled = true
    @AppStorage("settings.showMistakes") private var showMistakes = true
    @AppStorage("settings.penaltyMode") private var penaltyModeEnabled = false
    @AppStorage("settings.showConflicts") private var showConflicts = true
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    @State private var showResetConfirmation = false
    @State private var showResetFeedback = false

    var body: some View {
        VStack(spacing: 0) {
            List {
                Section {
                    Toggle("Sound", isOn: $soundEnabled)
                        .accessibilityIdentifier("settings_sound")
                    Toggle("Haptics", isOn: $hapticsEnabled)
                        .accessibilityIdentifier("settings_haptics")
                    Toggle("Show Mistakes", isOn: $showMistakes)
                        .accessibilityIdentifier("settings_show_mistakes")
                    Toggle("Penalty Mode (+15s per mistake)", isOn: $penaltyModeEnabled)
                        .accessibilityIdentifier("settings_penalty_mode")
                    Toggle("Show Conflicts", isOn: $showConflicts)
                        .accessibilityIdentifier("settings_show_conflicts")
                } footer: {
                    Text("These preferences apply to all puzzles.")
                        .foregroundColor(WordokuTheme.secondaryText)
                }
                .listRowBackground(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))

                Section {
                    Toggle("Liquid Glass Effects", isOn: $liquidGlassEnabled)
                        .accessibilityIdentifier("settings_liquid_glass")
                } footer: {
                    Text("Enable subtle blur and transparency effects throughout the app.")
                        .foregroundColor(WordokuTheme.secondaryText)
                }
                .listRowBackground(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))

                Section {
                    Button(role: .destructive) {
                        showResetConfirmation = true
                    } label: {
                        HStack {
                            Text("Reset All Progress")
                            Spacer()
                            Image(systemName: "arrow.counterclockwise")
                        }
                    }
                } footer: {
                    Text("This will erase all completed levels and saved games.")
                        .foregroundColor(WordokuTheme.secondaryText)
                }
                .listRowBackground(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .foregroundColor(WordokuTheme.primaryText)
        }
        .background(WordokuPaperBackground())
        .navigationTitle("Settings")
        .navigationBarTitleDisplayMode(.inline)
        .tint(WordokuTheme.accentBlue)
        .confirmationDialog(
            "Reset Progress",
            isPresented: $showResetConfirmation,
            titleVisibility: .visible
        ) {
            Button("Reset All Progress", role: .destructive) {
                ProgressStore.resetAllProgress()
                showResetFeedback = true
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This will permanently delete all your progress across all difficulty levels. This cannot be undone.")
        }
        .overlay {
            if showResetFeedback {
                ResetFeedbackOverlay(isVisible: $showResetFeedback)
            }
        }
    }
}

private struct ResetFeedbackOverlay: View {
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    @Binding var isVisible: Bool
    @State private var opacity: Double = 0

    var body: some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()

            VStack(spacing: WordokuTheme.spacingM) {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 48))
                    .foregroundColor(.green)

                Text("Progress Reset")
                    .font(.headline)
                    .foregroundColor(WordokuTheme.primaryText)

                Text("All progress has been cleared.")
                    .font(.subheadline)
                    .foregroundColor(WordokuTheme.secondaryText)
            }
            .padding(WordokuTheme.spacingXL)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))
            )
            .shadow(color: .black.opacity(0.2), radius: 20, y: 8)
        }
        .opacity(opacity)
        .onAppear {
            withAnimation(.easeOut(duration: 0.25)) {
                opacity = 1
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                withAnimation(.easeIn(duration: 0.25)) {
                    opacity = 0
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                    isVisible = false
                }
            }
        }
    }
}

#Preview {
    NavigationStack {
        SettingsView()
    }
}
