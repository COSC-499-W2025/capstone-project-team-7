import SwiftUI
import Combine

private enum DailyChallengeViewModel {
    case phrase(GameViewModel)
    case mini(MiniGameViewModel)

    var isComplete: Bool {
        switch self {
        case .phrase(let vm):
            return vm.isComplete
        case .mini(let vm):
            return vm.isComplete
        }
    }

    var isWordComplete: Bool {
        switch self {
        case .phrase(let vm):
            return vm.isWordComplete
        case .mini(let vm):
            return vm.isWordComplete
        }
    }

    var elapsedTime: TimeInterval {
        switch self {
        case .phrase(let vm):
            return vm.elapsedTime
        case .mini(let vm):
            return vm.elapsedTime
        }
    }

    var canUndo: Bool {
        switch self {
        case .phrase(let vm):
            return vm.canUndo
        case .mini(let vm):
            return vm.canUndo
        }
    }

    var canRedo: Bool {
        switch self {
        case .phrase(let vm):
            return vm.canRedo
        case .mini(let vm):
            return vm.canRedo
        }
    }

    var showConflicts: Bool {
        get {
            switch self {
            case .phrase(let vm):
                return vm.showConflicts
            case .mini(let vm):
                return vm.showConflicts
            }
        }
        set {
            switch self {
            case .phrase(let vm):
                vm.showConflicts = newValue
            case .mini(let vm):
                vm.showConflicts = newValue
            }
        }
    }

    var letters: [Character] {
        switch self {
        case .phrase(let vm):
            return vm.letters
        case .mini(let vm):
            return vm.letters
        }
    }

    var mistakeCount: Int {
        switch self {
        case .phrase(let vm):
            return vm.mistakeCount
        case .mini(let vm):
            return vm.mistakeCount
        }
    }

    var word: String {
        switch self {
        case .phrase(let vm):
            return vm.level.word.raw
        case .mini(let vm):
            return vm.level.word.raw
        }
    }

    func setValue(_ value: Int?) {
        switch self {
        case .phrase(let vm):
            vm.setValue(value)
        case .mini(let vm):
            vm.setValue(value)
        }
    }

    func undo() {
        switch self {
        case .phrase(let vm):
            vm.undo()
        case .mini(let vm):
            vm.undo()
        }
    }

    func redo() {
        switch self {
        case .phrase(let vm):
            vm.redo()
        case .mini(let vm):
            vm.redo()
        }
    }

    func setPenaltyMode(_ enabled: Bool) {
        switch self {
        case .phrase(let vm):
            vm.setPenaltyMode(enabled)
        case .mini(let vm):
            vm.setPenaltyMode(enabled)
        }
    }
}

struct DailyChallengeViewV2: View {
    @AppStorage("settings.showMistakes") private var showMistakes = true
    @AppStorage("settings.penaltyMode") private var penaltyModeEnabled = false
    @AppStorage("settings.showConflicts") private var showConflicts = true
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    @State private var viewModel: DailyChallengeViewModel
    @State private var puzzleType: DailyPuzzleType
    @State private var didNotify = false
    @State private var showCompletionPopup = false
    @State private var completionTime: TimeInterval = 0
    @State private var currentStreak: Int = 0
    @State private var personalBest: TimeInterval?
    @State private var isNewBest = false
    @State private var refreshNonce = false
    @State private var usedFallbackPuzzle = false

    private let manager = DailyChallengeManagerV2()
    @Environment(\.dismiss) private var dismiss

    init() {
        let manager = DailyChallengeManagerV2()
        let todayType = manager.todaysPuzzleType()
        if let puzzle = manager.generateTodaysPuzzle() {
            _puzzleType = State(initialValue: todayType)
            _usedFallbackPuzzle = State(initialValue: false)
            switch (todayType, puzzle) {
            case (.phrase, .phrase(let level)):
                _viewModel = State(initialValue: .phrase(GameViewModel(level: level)))
            case (.mini, .mini(let level)):
                _viewModel = State(initialValue: .mini(MiniGameViewModel(level: level)))
            case (_, .phrase(let level)):
                _puzzleType = State(initialValue: .phrase)
                _viewModel = State(initialValue: .phrase(GameViewModel(level: level)))
            case (_, .mini(let level)):
                _puzzleType = State(initialValue: .mini)
                _viewModel = State(initialValue: .mini(MiniGameViewModel(level: level)))
            }
            return
        }

        let fallbackLevel = Self.makeFallbackLevel()
        _puzzleType = State(initialValue: .phrase)
        _viewModel = State(initialValue: .phrase(GameViewModel(level: fallbackLevel)))
        _usedFallbackPuzzle = State(initialValue: true)
    }

    private static func makeFallbackLevel() -> WordokuLevel {
        let fallbackWord = WordokuWord(raw: "ABCDEFGHI")!
        var attemptSeed: UInt64 = 20260223
        let factory = WordokuLevelFactory()
        while attemptSeed < 20260233 {
            var rng: any RandomNumberGenerator = SeededGenerator(seed: attemptSeed)
            if let level = factory.makeLevel(word: fallbackWord, difficulty: .easy, forcedAxis: .row, forcedIndex: 0, rng: &rng) {
                return level
            }
            attemptSeed += 1
        }

        let solutionCells: [Int?] = [
            0, 1, 2, 3, 4, 5, 6, 7, 8,
            3, 4, 5, 6, 7, 8, 0, 1, 2,
            6, 7, 8, 0, 1, 2, 3, 4, 5,
            1, 2, 3, 4, 5, 6, 7, 8, 0,
            4, 5, 6, 7, 8, 0, 1, 2, 3,
            7, 8, 0, 1, 2, 3, 4, 5, 6,
            2, 3, 4, 5, 6, 7, 8, 0, 1,
            5, 6, 7, 8, 0, 1, 2, 3, 4,
            8, 0, 1, 2, 3, 4, 5, 6, 7,
        ]
        let solution = WordokuGrid(cells: solutionCells)
        var rng: any RandomNumberGenerator = SeededGenerator(seed: 1)
        let puzzle = WordokuPuzzleGenerator().generatePuzzle(from: solution, difficulty: .easy, rng: &rng)
        return WordokuLevel(word: fallbackWord, difficulty: .easy, puzzle: puzzle, solution: solution, forcedAxis: .row, forcedIndex: 0)
    }

    private var fallbackNotice: String? {
        usedFallbackPuzzle ? "Daily challenge data unavailable. Showing fallback puzzle." : nil
    }

    private var activeModelUpdates: AnyPublisher<Void, Never> {
        switch viewModel {
        case .phrase(let vm):
            return vm.objectWillChange.eraseToAnyPublisher()
        case .mini(let vm):
            return vm.objectWillChange.eraseToAnyPublisher()
        }
    }

    var body: some View {
        let _ = refreshNonce
        ZStack(alignment: .top) {
            ScrollView {
                VStack(spacing: WordokuTheme.spacingL) {
                    DailyChallengeHeader(
                        title: headerTitle,
                        word: viewModel.word,
                        elapsedTime: viewModel.elapsedTime,
                        mistakeCount: viewModel.mistakeCount,
                        showMistakes: showMistakes,
                        penaltyModeEnabled: penaltyModeEnabled
                    )

                    if let fallbackNotice {
                        Text(fallbackNotice)
                            .font(.footnote)
                            .foregroundColor(WordokuTheme.secondaryText)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, WordokuTheme.spacingL)
                    }

                    if case .phrase(let gameVM) = viewModel {
                        GridView(
                            grid: gameVM.grid,
                            letters: gameVM.letters,
                            selectedIndex: gameVM.selectedIndex,
                            givenIndices: gameVM.givenIndices,
                            conflictIndices: gameVM.conflictIndices,
                            forcedIndices: gameVM.forcedIndices,
                            orderedForcedIndices: gameVM.orderedForcedIndices,
                            isComplete: gameVM.isComplete,
                            isWordComplete: gameVM.isWordComplete,
                            onSelect: { gameVM.select(index: $0) }
                        )
                        .aspectRatio(1, contentMode: .fit)
                        .padding(.horizontal, WordokuTheme.spacingM)
                    } else if case .mini(let miniVM) = viewModel {
                        MiniGridView(
                            grid: miniVM.grid,
                            letters: miniVM.letters,
                            selectedIndex: miniVM.selectedIndex,
                            givenIndices: miniVM.givenIndices,
                            conflictIndices: miniVM.conflictIndices,
                            forcedIndices: miniVM.forcedIndices,
                            orderedForcedIndices: miniVM.orderedForcedIndices,
                            isComplete: miniVM.isComplete,
                            isWordComplete: miniVM.isWordComplete,
                            onSelect: { miniVM.select(index: $0) }
                        )
                        .aspectRatio(1, contentMode: .fit)
                        .padding(.horizontal, WordokuTheme.spacingM)
                    }

                    DailyChallengeControls(
                        letters: viewModel.letters,
                        onSelectIndex: { viewModel.setValue($0) },
                        onDelete: { viewModel.setValue(nil) },
                        onLongDelete: { viewModel.undo() },
                        liquidGlassEnabled: liquidGlassEnabled
                    )

                    Spacer(minLength: WordokuTheme.spacingXL)
                }
                .padding(.top, WordokuTheme.spacingM)
            }
            .background(WordokuPaperBackground())

            if viewModel.isComplete {
                WinOverlayView(forcedWord: viewModel.word)
                    .padding(.top, WordokuTheme.spacingM)
                    .transition(.opacity)
            }

            if showCompletionPopup {
                DailyCompletionPopupOverlay(
                    title: headerTitle,
                    word: viewModel.word,
                    completionTime: completionTime,
                    streak: currentStreak,
                    personalBestTime: personalBest,
                    isNewBest: isNewBest,
                    onDismiss: { dismiss() },
                    onContinue: { dismiss() }
                )
            }
        }
        .animation(.easeInOut(duration: 0.18), value: viewModel.isComplete)
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                HStack(spacing: 12) {
                    Button(action: { viewModel.undo() }) {
                        Image(systemName: "arrow.uturn.backward")
                            .foregroundColor(WordokuTheme.accentBlue)
                    }
                    .disabled(!viewModel.canUndo)
                    .opacity(viewModel.canUndo ? 1.0 : 0.3)
                    .accessibilityLabel("Undo")

                    Button(action: { viewModel.redo() }) {
                        Image(systemName: "arrow.uturn.forward")
                            .foregroundColor(WordokuTheme.accentBlue)
                    }
                    .disabled(!viewModel.canRedo)
                    .opacity(viewModel.canRedo ? 1.0 : 0.3)
                    .accessibilityLabel("Redo")
                }
            }
        }
        .onAppear {
            viewModel.setPenaltyMode(penaltyModeEnabled)
            viewModel.showConflicts = showConflicts
            currentStreak = manager.getCurrentStreak()
            personalBest = manager.getPersonalBest(for: puzzleType)
        }
        .onChange(of: showConflicts) { enabled in
            viewModel.showConflicts = enabled
        }
        .onChange(of: penaltyModeEnabled) { enabled in
            viewModel.setPenaltyMode(enabled)
        }
        .onChange(of: viewModel.isComplete) { newValue in
            if newValue && !didNotify {
                didNotify = true
                completionTime = viewModel.elapsedTime

                let previousBest = manager.getPersonalBest(for: puzzleType)
                isNewBest = previousBest == nil || viewModel.elapsedTime < (previousBest ?? .infinity)

                manager.markTodayComplete(time: viewModel.elapsedTime, type: puzzleType)
                currentStreak = manager.getCurrentStreak()
                personalBest = manager.getPersonalBest(for: puzzleType)

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                        showCompletionPopup = true
                    }
                }
            }
        }
        .onReceive(activeModelUpdates) { _ in
            refreshNonce.toggle()
        }
    }

    private var headerTitle: String {
        switch puzzleType {
        case .phrase:
            return "DAILY PHRASE"
        case .mini:
            return "DAILY MINI"
        }
    }
}

private struct DailyChallengeHeader: View {
    let title: String
    let word: String
    let elapsedTime: TimeInterval
    let mistakeCount: Int
    let showMistakes: Bool
    let penaltyModeEnabled: Bool

    var body: some View {
        VStack(spacing: WordokuTheme.spacingS) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundColor(WordokuTheme.secondaryText)
                .tracking(1.2)

            Text(word.uppercased())
                .font(.system(size: 32, weight: .bold, design: .serif))
                .tracking(6)
                .foregroundColor(WordokuTheme.titleColor)

            Text(formatTime(elapsedTime))
                .font(.system(size: 18, weight: .semibold, design: .monospaced))
                .foregroundColor(WordokuTheme.secondaryText)
                .accessibilityIdentifier("daily_timer")

            if showMistakes {
                HStack(spacing: WordokuTheme.spacingXS) {
                    Text("Mistakes: \(mistakeCount)")
                        .font(.footnote.weight(.semibold))
                        .foregroundColor(mistakeCount == 0 ? WordokuTheme.secondaryText : WordokuTheme.accentInk)
                    if penaltyModeEnabled {
                        Text("(+15s each)")
                            .font(.footnote)
                            .foregroundColor(WordokuTheme.secondaryText)
                    }
                }
            }
        }
        .padding(.vertical, WordokuTheme.spacingS)
    }

    private func formatTime(_ seconds: TimeInterval) -> String {
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%d:%02d", mins, secs)
    }
}

private struct DailyChallengeControls: View {
    let letters: [Character]
    let onSelectIndex: (Int) -> Void
    let onDelete: () -> Void
    let onLongDelete: () -> Void
    let liquidGlassEnabled: Bool

    var body: some View {
        VStack(spacing: WordokuTheme.spacingM) {
            LetterPaletteView(
                letters: letters,
                onSelect: onSelectIndex,
                onDelete: onDelete,
                onLongDelete: onLongDelete
            )
            .padding(.horizontal, WordokuTheme.spacingL)
        }
    }
}

private struct DailyCompletionPopupOverlay: View {
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    let title: String
    let word: String
    let completionTime: TimeInterval
    let streak: Int
    let personalBestTime: TimeInterval?
    let isNewBest: Bool
    let onDismiss: () -> Void
    let onContinue: () -> Void
    @State private var isVisible = false

    var body: some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()
                .onTapGesture {
                    onDismiss()
                }

            VStack(spacing: WordokuTheme.spacingL) {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 56))
                    .foregroundColor(WordokuTheme.accentBlue)

                VStack(spacing: WordokuTheme.spacingS) {
                    Text("Challenge Complete!")
                        .font(.system(size: 24, weight: .bold, design: .serif))
                        .foregroundColor(WordokuTheme.primaryText)

                    Text(title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(WordokuTheme.secondaryText)

                    Text(word.uppercased())
                        .font(.system(size: 28, weight: .semibold, design: .serif))
                        .tracking(4)
                        .foregroundColor(WordokuTheme.accentBlue)
                        .padding(.top, WordokuTheme.spacingXS)

                    Text("Time: \(formatTime(completionTime))")
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(WordokuTheme.primaryText)

                    Text("Streak: \(streak) day\(streak == 1 ? "" : "s")")
                        .font(.footnote.weight(.medium))
                        .foregroundColor(WordokuTheme.secondaryText)

                    if let personalBestTime {
                        HStack(spacing: WordokuTheme.spacingXS) {
                            Text("Best: \(formatTime(personalBestTime))")
                                .font(.footnote.weight(.medium))
                                .foregroundColor(WordokuTheme.secondaryText)
                            if isNewBest {
                                Text("New Best!")
                                    .font(.caption.weight(.bold))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 4)
                                    .background(
                                        Capsule()
                                            .fill(WordokuTheme.accentBlue)
                                    )
                            }
                        }
                    }
                }

                Button(action: onContinue) {
                    Text("Continue")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(WordokuTheme.accentBlue)
                        .cornerRadius(12)
                }
                .padding(.top, WordokuTheme.spacingS)
            }
            .padding(WordokuTheme.spacingXL)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))
                    .overlay(
                        RoundedRectangle(cornerRadius: 24)
                            .stroke(WordokuTheme.divider, lineWidth: WordokuTheme.borderWidth)
                    )
            )
            .shadow(color: Color.black.opacity(0.2), radius: 24, y: 12)
            .padding(WordokuTheme.spacingL)
            .opacity(isVisible ? 1 : 0)
            .scaleEffect(isVisible ? 1 : 0.9)
        }
        .onAppear {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
                isVisible = true
            }
        }
    }

    private func formatTime(_ seconds: TimeInterval) -> String {
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%d:%02d", mins, secs)
    }
}
