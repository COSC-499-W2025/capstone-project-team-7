import SwiftUI

struct LetterPaletteView: View {
    let letters: [Character]
    let onSelect: (Int) -> Void
    let onDelete: () -> Void
    let onLongDelete: (() -> Void)?

    init(
        letters: [Character],
        onSelect: @escaping (Int) -> Void,
        onDelete: @escaping () -> Void,
        onLongDelete: (() -> Void)? = nil
    ) {
        self.letters = letters
        self.onSelect = onSelect
        self.onDelete = onDelete
        self.onLongDelete = onLongDelete
    }

    private var totalButtons: Int {
        letters.count + 1
    }

    private var columnCount: Int {
        min(5, max(1, Int(ceil(Double(totalButtons) / 2.0))))
    }

    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: WordokuTheme.spacingS), count: columnCount)
    }

    var body: some View {
        LazyVGrid(columns: columns, spacing: WordokuTheme.spacingS) {
            ForEach(0..<letters.count, id: \.self) { index in
                paletteButton(label: String(letters[index]), accessibilityLabel: "Letter \(letters[index])") {
                    onSelect(index)
                }
            }
            deleteButton {
                onDelete()
            }
        }
        .padding(WordokuTheme.spacingM)
        .wordokuCard()
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Letter palette")
    }

    private func paletteButton(label: String, accessibilityLabel: String, action: @escaping () -> Void) -> some View {
        let key = KeyEquivalent(Character(label.lowercased()))
        return Button(action: action) {
            Text(label)
                .font(.headline)
                .foregroundColor(WordokuTheme.primaryText)
                .frame(maxWidth: .infinity, minHeight: 44)
                .background(WordokuTheme.background)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(WordokuTheme.divider, lineWidth: 1)
                )
                .cornerRadius(10)
        }
        .buttonStyle(.plain)
        .keyboardShortcut(key, modifiers: [])
        .accessibilityLabel(accessibilityLabel)
        .accessibilityHint("Double tap to enter this value")
        .accessibilityIdentifier("palette_\(label)")
    }

    private func deleteButton(action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: "delete.backward")
                .font(.headline)
                .foregroundColor(WordokuTheme.primaryText)
                .frame(maxWidth: .infinity, minHeight: 44)
                .background(WordokuTheme.background)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(WordokuTheme.divider, lineWidth: 1)
                )
                .cornerRadius(10)
        }
        .buttonStyle(.plain)
        .keyboardShortcut(.delete, modifiers: [])
        .simultaneousGesture(
            LongPressGesture(minimumDuration: 0.35)
                .onEnded { _ in
                    onLongDelete?()
                }
        )
        .accessibilityLabel("Delete")
        .accessibilityHint("Double tap to delete the selected cell value, long press to undo")
        .accessibilityIdentifier("palette_delete")
    }
}
