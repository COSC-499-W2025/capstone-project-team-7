import SwiftUI

struct WinOverlayView: View {
    let forcedWord: String
    @State private var isVisible = false
    @State private var checkmarkScale: CGFloat = 0.3
    @State private var revealedLetterCount: Int = 0

    var body: some View {
        HStack(spacing: WordokuTheme.spacingS) {
            Image(systemName: "checkmark.circle.fill")
                .foregroundColor(WordokuTheme.accentBlue)
                .scaleEffect(checkmarkScale)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text("Level Complete")
                    .font(.headline)
                    .foregroundColor(WordokuTheme.primaryText)
                    .opacity(isVisible ? 1 : 0)
                HStack(spacing: 1) {
                    Text("Reveal: ")
                        .wordokuSubtleText()
                        .opacity(isVisible ? 1 : 0)
                    ForEach(Array(forcedWord.enumerated()), id: \.offset) { index, letter in
                        Text(String(letter))
                            .font(.footnote.weight(.semibold))
                            .foregroundColor(WordokuTheme.accentBlue)
                            .opacity(index < revealedLetterCount ? 1 : 0)
                            .scaleEffect(index < revealedLetterCount ? 1 : 0.5)
                            .animation(
                                .spring(response: 0.3, dampingFraction: 0.6)
                                    .delay(Double(index) * 0.06),
                                value: revealedLetterCount
                            )
                    }
                }
            }
        }
        .padding(.horizontal, WordokuTheme.spacingL)
        .padding(.vertical, WordokuTheme.spacingS)
        .background(WordokuTheme.cardBackground)
        .overlay(
            RoundedRectangle(cornerRadius: 999)
                .stroke(WordokuTheme.divider, lineWidth: 1)
        )
        .clipShape(Capsule())
        .shadow(color: Color.black.opacity(0.08), radius: 8, x: 0, y: 3)
        .scaleEffect(isVisible ? 1 : 0.9)
        .opacity(isVisible ? 1 : 0)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Level complete! The hidden word is \(forcedWord)")
        .accessibilityAddTraits(.isStaticText)
        .onAppear {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                isVisible = true
                checkmarkScale = 1.0
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                revealedLetterCount = forcedWord.count
            }
        }
    }
}
