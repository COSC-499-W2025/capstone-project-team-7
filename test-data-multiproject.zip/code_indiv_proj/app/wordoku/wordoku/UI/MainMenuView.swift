import SwiftUI

struct MainMenuView: View {
    @State private var summary = ProgressSummary(
        easyLevelCount: 0,
        mediumLevelCount: 0,
        hardLevelCount: 0,
        easyCompleted: 0,
        mediumCompleted: 0,
        hardCompleted: 0
    )
    @State private var preferredDifficulty: Difficulty = .easy
    @State private var headerVisible = false
    @State private var cardsVisible = false
    private let levelCount: Int = {
        let loader = WordListLoader()
        var seen = Set<String>()
        return loader.loadWords().filter { seen.insert($0.raw).inserted }.count
    }()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    HeroHeader(headerVisible: headerVisible)
                        .padding(.bottom, WordokuTheme.spacingXL)

                    ProgressSection(
                        summary: summary,
                        isVisible: cardsVisible
                    )
                    .padding(.bottom, WordokuTheme.spacingL)

                    ActionSection(
                        preferredDifficulty: preferredDifficulty,
                        isVisible: cardsVisible
                    )

                    Spacer(minLength: WordokuTheme.spacingXL)
                }
                .padding(.horizontal, WordokuTheme.spacingL)
                .padding(.top, WordokuTheme.spacingXL)
                .padding(.bottom, WordokuTheme.spacingL)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(WordokuPaperBackground())
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                summary = ProgressStore.loadSummary(levelCount: max(levelCount, 1))
                preferredDifficulty = ProgressStore.loadSelectedDifficulty()
                withAnimation(.easeOut(duration: 0.5)) {
                    headerVisible = true
                }
                withAnimation(.easeOut(duration: 0.6).delay(0.15)) {
                    cardsVisible = true
                }
            }
        }
    }
}

private struct HeroHeader: View {
    let headerVisible: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: WordokuTheme.spacingM) {
            Text("Wordoku")
                .font(.system(size: 48, weight: .semibold, design: .serif))
                .foregroundColor(WordokuTheme.titleColor)
                .opacity(headerVisible ? 1 : 0)
                .offset(y: headerVisible ? 0 : 10)
            
            HStack(spacing: WordokuTheme.spacingS) {
                Rectangle()
                    .fill(WordokuTheme.accentBlue)
                    .frame(width: 24, height: 2)
                Text("Letter puzzles, hidden words")
                    .font(.subheadline.weight(.medium))
                    .foregroundColor(WordokuTheme.secondaryText)
                    .tracking(0.3)
            }
            .opacity(headerVisible ? 1 : 0)
            .offset(y: headerVisible ? 0 : 8)
        }
    }
}

private struct ProgressSection: View {
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    let summary: ProgressSummary
    let isVisible: Bool
    
    private var completionPercentage: Double {
        guard summary.totalAvailable > 0 else { return 0 }
        return Double(summary.totalCompleted) / Double(summary.totalAvailable)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: WordokuTheme.spacingM) {
            Text("YOUR PROGRESS")
                .font(.caption.weight(.semibold))
                .foregroundColor(WordokuTheme.secondaryText)
                .tracking(1.5)
            
            HStack(alignment: .top, spacing: WordokuTheme.spacingL) {
                CircularProgressView(
                    progress: completionPercentage,
                    total: summary.totalCompleted,
                    available: summary.totalAvailable
                )
                .frame(width: 90, height: 90)
                
                VStack(alignment: .leading, spacing: WordokuTheme.spacingS) {
                    DifficultyRow(title: "Easy", completed: summary.easyCompleted, total: summary.easyLevelCount, color: WordokuTheme.accentBlue)
                    DifficultyRow(title: "Medium", completed: summary.mediumCompleted, total: summary.mediumLevelCount, color: WordokuTheme.accentYellow)
                    DifficultyRow(title: "Hard", completed: summary.hardCompleted, total: summary.hardLevelCount, color: WordokuTheme.accentInk)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(WordokuTheme.spacingM)
                .background(
                    RoundedRectangle(cornerRadius: WordokuTheme.cornerRadius)
                        .fill(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))
                        .overlay(
                            RoundedRectangle(cornerRadius: WordokuTheme.cornerRadius)
                                .stroke(WordokuTheme.divider, lineWidth: WordokuTheme.borderWidth)
                        )
                )
            .shadow(color: WordokuTheme.cardShadow(liquidGlassEnabled: liquidGlassEnabled), radius: 12, x: 0, y: 6)
        }
        .opacity(isVisible ? 1 : 0)
        .offset(y: isVisible ? 0 : 12)
    }
}

private struct CircularProgressView: View {
    let progress: Double
    let total: Int
    let available: Int
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(WordokuTheme.subtleFill, lineWidth: 6)
            
            Circle()
                .trim(from: 0, to: progress)
                .stroke(
                    WordokuTheme.accentBlue,
                    style: StrokeStyle(lineWidth: 6, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 0.8), value: progress)
            
            VStack(spacing: 0) {
                Text("\(total)")
                    .font(.system(size: 22, weight: .bold, design: .default))
                    .foregroundColor(WordokuTheme.primaryText)
                Text("/\(available)")
                    .font(.caption2.weight(.medium))
                    .foregroundColor(WordokuTheme.secondaryText)
            }
        }
    }
}

private struct DifficultyRow: View {
    let title: String
    let completed: Int
    let total: Int
    let color: Color
    
    private var progress: Double {
        guard total > 0 else { return 0 }
        return Double(completed) / Double(total)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(title)
                    .font(.footnote.weight(.medium))
                    .foregroundColor(WordokuTheme.primaryText)
                Spacer()
                Text("\(completed)/\(total)")
                    .font(.caption.weight(.semibold))
                    .foregroundColor(WordokuTheme.secondaryText)
            }
            
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(WordokuTheme.subtleFill)
                    RoundedRectangle(cornerRadius: 2)
                        .fill(color)
                        .frame(width: geo.size.width * progress)
                        .animation(.easeOut(duration: 0.6), value: progress)
                }
            }
            .frame(height: 4)
        }
    }
}

private struct ActionSection: View {
    let preferredDifficulty: Difficulty
    let isVisible: Bool
    
    var body: some View {
        VStack(spacing: WordokuTheme.spacingM) {
            NavigationLink {
                DailyChallengeViewV2()
            } label: {
                DailyChallengeCard()
            }
            .accessibilityIdentifier("main_daily_card")

            NavigationLink {
                LevelSelectView()
            } label: {
                PrimaryActionCard(difficulty: preferredDifficulty)
            }
            .accessibilityIdentifier("main_continue_card")

            NavigationLink {
                SettingsView()
            } label: {
                SecondaryActionCard()
            }
            .accessibilityIdentifier("main_settings_card")
        }
        .opacity(isVisible ? 1 : 0)
        .offset(y: isVisible ? 0 : 12)
    }
}

private struct PrimaryActionCard: View {
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    let difficulty: Difficulty
    
    var body: some View {
        HStack(spacing: WordokuTheme.spacingM) {
            VStack(alignment: .leading, spacing: WordokuTheme.spacingXS) {
                Text("Continue Playing")
                    .font(.headline)
                    .foregroundColor(WordokuTheme.primaryText)
                Text("\(difficulty.rawValue.capitalized) difficulty")
                    .font(.subheadline)
                    .foregroundColor(WordokuTheme.secondaryText)
            }
            
            Spacer()
            
            ZStack {
                Circle()
                    .fill(WordokuTheme.accentBlue)
                    .frame(width: 44, height: 44)
                Image(systemName: "arrow.right")
                    .font(.body.weight(.semibold))
                    .foregroundColor(.white)
            }
        }
        .padding(WordokuTheme.spacingM)
        .background(
            RoundedRectangle(cornerRadius: WordokuTheme.cornerRadius)
                .fill(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))
                .overlay(
                    RoundedRectangle(cornerRadius: WordokuTheme.cornerRadius)
                        .fill(WordokuTheme.accentBlueWash)
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: WordokuTheme.cornerRadius)
                .stroke(WordokuTheme.divider, lineWidth: WordokuTheme.borderWidth)
        )
        .shadow(color: WordokuTheme.cardShadow(liquidGlassEnabled: liquidGlassEnabled), radius: 12, x: 0, y: 6)
        .accessibilityIdentifier("main_continue_card")
    }
}

private struct SecondaryActionCard: View {
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    var body: some View {
        HStack(spacing: WordokuTheme.spacingS) {
            Image(systemName: "slider.horizontal.3")
                .font(.body.weight(.medium))
                .foregroundColor(WordokuTheme.secondaryText)
            
            Text("Settings")
                .font(.subheadline.weight(.medium))
                .foregroundColor(WordokuTheme.primaryText)
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundColor(WordokuTheme.secondaryText.opacity(0.6))
        }
        .padding(.horizontal, WordokuTheme.spacingM)
        .padding(.vertical, 14)
        .background(
            RoundedRectangle(cornerRadius: WordokuTheme.cornerRadius)
                .fill(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))
        )
        .overlay(
            RoundedRectangle(cornerRadius: WordokuTheme.cornerRadius)
                .stroke(WordokuTheme.divider, lineWidth: WordokuTheme.borderWidth)
        )
        .accessibilityIdentifier("main_settings_card")
    }
}

private struct DailyChallengeCard: View {
    @AppStorage("settings.liquidGlass") private var liquidGlassEnabled = false
    @State private var manager = DailyChallengeManagerV2()
    @State private var isComplete = false
    @State private var puzzleType: DailyPuzzleType = .phrase
    @State private var streak = 0
    
    var body: some View {
        HStack(spacing: WordokuTheme.spacingM) {
            VStack(alignment: .leading, spacing: WordokuTheme.spacingXS) {
                HStack(spacing: WordokuTheme.spacingXS) {
                    Text("Daily Challenge")
                        .font(.headline)
                        .foregroundColor(WordokuTheme.primaryText)
                    if isComplete {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(WordokuTheme.accentBlue)
                            .font(.subheadline)
                    }
                }
                
                HStack(spacing: WordokuTheme.spacingS) {
                    Text(puzzleType == .phrase ? "Phrase Puzzle" : "Mini Puzzle")
                        .font(.subheadline)
                        .foregroundColor(WordokuTheme.secondaryText)
                    
                    if streak > 0 {
                        HStack(spacing: 2) {
                            Text("🔥")
                                .font(.caption)
                            Text("\(streak)")
                                .font(.caption.weight(.semibold))
                                .foregroundColor(WordokuTheme.primaryText)
                        }
                    }
                }
            }
            
            Spacer()
            
            ZStack {
                Circle()
                    .fill(isComplete ? WordokuTheme.subtleFill : WordokuTheme.accentBlue)
                    .frame(width: 44, height: 44)
                Image(systemName: isComplete ? "checkmark" : "calendar")
                    .font(.body.weight(.semibold))
                    .foregroundColor(isComplete ? WordokuTheme.secondaryText : .white)
            }
        }
        .padding(WordokuTheme.spacingM)
        .background(
            RoundedRectangle(cornerRadius: WordokuTheme.cornerRadius)
                .fill(WordokuTheme.cardBackground(liquidGlassEnabled: liquidGlassEnabled))
                .overlay(
                    RoundedRectangle(cornerRadius: WordokuTheme.cornerRadius)
                        .stroke(WordokuTheme.divider, lineWidth: WordokuTheme.borderWidth)
                )
        )
        .accessibilityIdentifier("main_daily_card")
        .onAppear {
            isComplete = manager.isTodayComplete()
            puzzleType = manager.todaysPuzzleType()
            streak = manager.getCurrentStreak()
        }
    }
}
