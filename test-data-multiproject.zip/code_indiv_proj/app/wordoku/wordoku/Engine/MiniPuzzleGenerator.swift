import Foundation

public struct MiniPuzzleGenerator {
    public init() {}

    public func generatePuzzle(from solution: MiniGrid, difficulty: Difficulty, rng: inout RandomNumberGenerator) -> MiniGrid {
        var puzzle = solution
        var indices = Array(0..<36)
        indices.shuffle(using: &rng)
        let target = targetGivens(for: difficulty)
        let minPerBox = minGivensPerBox(for: difficulty)
        let solver = MiniSolver()

        for idx in indices {
            if puzzle.givenCount() <= target { break }
            let pair = 35 - idx
            let removal = Array(Set([idx, pair]))
            if removal.allSatisfy({ puzzle.cells[$0] == nil }) { continue }
            if puzzle.givenCount() - removal.count < target { continue }
            let saved = removal.map { puzzle.cells[$0] }
            for index in removal { puzzle.cells[index] = nil }
            if violatesBoxMinimum(puzzle, minPerBox: minPerBox) || solver.countSolutions(puzzle, limit: 2) != 1 {
                for (offset, index) in removal.enumerated() { puzzle.cells[index] = saved[offset] }
            }
        }
        return puzzle
    }

    private func targetGivens(for difficulty: Difficulty) -> Int {
        switch difficulty {
        case .easy: return 18
        case .medium: return 14
        case .hard: return 10
        }
    }

    private func minGivensPerBox(for difficulty: Difficulty) -> Int {
        switch difficulty {
        case .easy: return 2
        case .medium: return 1
        case .hard: return 1
        }
    }

    private func violatesBoxMinimum(_ grid: MiniGrid, minPerBox: Int) -> Bool {
        for box in 0..<6 {
            let count = MiniGrid.boxIndices(box).reduce(0) { total, index in
                total + (grid.cells[index] == nil ? 0 : 1)
            }
            if count < minPerBox { return true }
        }
        return false
    }
}
