import Foundation

public struct MiniCellIndex: Hashable {
    public let row: Int
    public let col: Int

    public init(row: Int, col: Int) {
        self.row = row
        self.col = col
    }

    public var linearIndex: Int {
        row * 6 + col
    }
}

public struct MiniGrid: Equatable {
    public var cells: [Int?]

    public init() {
        self.cells = Array(repeating: nil, count: 36)
    }

    public init(cells: [Int?]) {
        if cells.count == 36 {
            self.cells = cells
        } else if cells.count < 36 {
            self.cells = cells + Array(repeating: nil, count: 36 - cells.count)
        } else {
            self.cells = Array(cells.prefix(36))
        }
    }

    public subscript(row: Int, col: Int) -> Int? {
        get { cells[row * 6 + col] }
        set { cells[row * 6 + col] = newValue }
    }

    public func givenCount() -> Int {
        cells.compactMap { $0 }.count
    }

    public static func row(of index: Int) -> Int {
        index / 6
    }

    public static func col(of index: Int) -> Int {
        index % 6
    }

    public static func box(of index: Int) -> Int {
        (row(of: index) / 2) * 2 + (col(of: index) / 3)
    }

    public static func rowIndices(_ row: Int) -> [Int] {
        (0..<6).map { row * 6 + $0 }
    }

    public static func colIndices(_ col: Int) -> [Int] {
        (0..<6).map { $0 * 6 + col }
    }

    public static func boxIndices(_ box: Int) -> [Int] {
        let startRow = (box / 2) * 2
        let startCol = (box % 2) * 3
        var indices: [Int] = []
        indices.reserveCapacity(6)
        for r in 0..<2 {
            for c in 0..<3 {
                indices.append((startRow + r) * 6 + (startCol + c))
            }
        }
        return indices
    }

    public static func peers(of index: Int) -> Set<Int> {
        let rowIdx = row(of: index)
        let colIdx = col(of: index)
        let boxIdx = box(of: index)
        var peers = Set<Int>()
        peers.formUnion(rowIndices(rowIdx))
        peers.formUnion(colIndices(colIdx))
        peers.formUnion(boxIndices(boxIdx))
        peers.remove(index)
        return peers
    }
}
