import Foundation

public struct MiniSolutionGenerator {
    public init() {}

    public func generateSolution(word: MiniWord, forcedAxis: ForcedAxis, forcedIndex: Int, rng: inout RandomNumberGenerator) -> MiniGrid? {
        var grid = MiniGrid()
        for i in 0..<6 {
            let index: Int
            switch forcedAxis {
            case .row:
                index = forcedIndex * 6 + i
            case .col:
                index = i * 6 + forcedIndex
            case .diagonal:
                index = i * 7
            case .antiDiagonal:
                index = (i + 1) * 5
            }
            grid.cells[index] = i
        }
        guard MiniValidator.isValid(grid: grid) else { return nil }
        if fillGrid(&grid, rng: &rng) { return grid }
        return nil
    }

    private func fillGrid(_ grid: inout MiniGrid, rng: inout RandomNumberGenerator) -> Bool {
        guard let next = nextCell(in: grid) else { return true }
        if next.candidates.isEmpty { return false }
        var candidates = next.candidates
        candidates.shuffle(using: &rng)
        for value in candidates {
            grid.cells[next.index] = value
            if fillGrid(&grid, rng: &rng) { return true }
        }
        grid.cells[next.index] = nil
        return false
    }

    private func nextCell(in grid: MiniGrid) -> (index: Int, candidates: [Int])? {
        var bestIndex: Int?
        var bestCandidates: [Int] = []
        var bestCount = Int.max
        for idx in 0..<36 where grid.cells[idx] == nil {
            let candidates = candidates(for: idx, grid: grid)
            if candidates.isEmpty { return (idx, []) }
            if candidates.count < bestCount {
                bestCount = candidates.count
                bestIndex = idx
                bestCandidates = candidates
                if bestCount == 1 { break }
            }
        }
        guard let index = bestIndex else { return nil }
        return (index, bestCandidates)
    }

    private func candidates(for index: Int, grid: MiniGrid) -> [Int] {
        var available = Array(repeating: true, count: 6)
        for peer in MiniGrid.peers(of: index) {
            if let value = grid.cells[peer] {
                available[value] = false
            }
        }
        var result: [Int] = []
        for value in 0..<6 where available[value] {
            result.append(value)
        }
        return result
    }
}
