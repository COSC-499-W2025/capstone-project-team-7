import Foundation

public struct MiniValidator {
    public init() {}

    public static func isValid(grid: MiniGrid) -> Bool {
        for row in 0..<6 {
            if hasDuplicates(indices: MiniGrid.rowIndices(row), grid: grid) { return false }
        }
        for col in 0..<6 {
            if hasDuplicates(indices: MiniGrid.colIndices(col), grid: grid) { return false }
        }
        for box in 0..<6 {
            if hasDuplicates(indices: MiniGrid.boxIndices(box), grid: grid) { return false }
        }
        return true
    }

    public static func isComplete(grid: MiniGrid) -> Bool {
        !grid.cells.contains(where: { $0 == nil }) && isValid(grid: grid)
    }

    public static func isValidPlacement(grid: MiniGrid, index: Int, value: Int) -> Bool {
        let peers = MiniGrid.peers(of: index)
        for peer in peers {
            if grid.cells[peer] == value { return false }
        }
        return true
    }

    public static func conflictingIndices(in grid: MiniGrid) -> Set<Int> {
        var conflicts = Set<Int>()
        for row in 0..<6 {
            conflicts.formUnion(conflictsIn(indices: MiniGrid.rowIndices(row), grid: grid))
        }
        for col in 0..<6 {
            conflicts.formUnion(conflictsIn(indices: MiniGrid.colIndices(col), grid: grid))
        }
        for box in 0..<6 {
            conflicts.formUnion(conflictsIn(indices: MiniGrid.boxIndices(box), grid: grid))
        }
        return conflicts
    }

    private static func hasDuplicates(indices: [Int], grid: MiniGrid) -> Bool {
        var seen = Set<Int>()
        for idx in indices {
            if let value = grid.cells[idx] {
                if seen.contains(value) { return true }
                seen.insert(value)
            }
        }
        return false
    }

    private static func conflictsIn(indices: [Int], grid: MiniGrid) -> Set<Int> {
        var positionsByValue: [Int: [Int]] = [:]
        for idx in indices {
            if let value = grid.cells[idx] {
                positionsByValue[value, default: []].append(idx)
            }
        }
        var conflicts = Set<Int>()
        for (_, positions) in positionsByValue where positions.count > 1 {
            conflicts.formUnion(positions)
        }
        return conflicts
    }
}
