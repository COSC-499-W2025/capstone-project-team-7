import Foundation
import SwiftUI
import Combine

final class GameViewModel: ObservableObject {
    let level: WordokuLevel
    @Published var grid: WordokuGrid
    @Published var selectedIndex: Int?
    @Published var showConflicts: Bool = true
    @Published var isComplete: Bool = false
    @Published var isWordComplete: Bool = false
    @Published var canUndo: Bool = false
    @Published var canRedo: Bool = false
    @Published var elapsedTime: TimeInterval = 0
    @Published var mistakeCount: Int = 0

    private var undoStack: [(index: Int, oldValue: Int?, newValue: Int?)] = []
    private var redoStack: [(index: Int, oldValue: Int?, newValue: Int?)] = []
    private var timerStarted = false
    private var timer: Timer?
    private var penaltyModeEnabled = false
    private let penaltySeconds: TimeInterval = 15

    init(level: WordokuLevel) {
        self.level = level
        self.grid = level.puzzle
        self.selectedIndex = nil
        self.isComplete = false
        self.isWordComplete = false
        self.canUndo = false
        self.canRedo = false
        self.mistakeCount = 0
        updateWinState()
    }

    var letters: [Character] {
        level.word.letters
    }

    var givenIndices: Set<Int> {
        var indices = Set<Int>()
        for idx in 0..<81 where level.puzzle.cells[idx] != nil {
            indices.insert(idx)
        }
        return indices
    }

    var conflictIndices: Set<Int> {
        guard showConflicts else { return [] }
        return WordokuValidator.conflictingIndices(in: grid)
    }

    var forcedIndices: Set<Int> {
        switch level.forcedAxis {
        case .row:
            return Set(WordokuGrid.rowIndices(level.forcedIndex))
        case .col:
            return Set(WordokuGrid.colIndices(level.forcedIndex))
        case .diagonal:
            return Set(WordokuGrid.mainDiagonalIndices())
        case .antiDiagonal:
            return Set(WordokuGrid.antiDiagonalIndices())
        }
    }
    
    var orderedForcedIndices: [Int] {
        switch level.forcedAxis {
        case .row:
            return WordokuGrid.rowIndices(level.forcedIndex)
        case .col:
            return WordokuGrid.colIndices(level.forcedIndex)
        case .diagonal:
            return WordokuGrid.mainDiagonalIndices()
        case .antiDiagonal:
            return WordokuGrid.antiDiagonalIndices()
        }
    }

    func letter(for value: Int?) -> String {
        guard let value = value, value >= 0, value < letters.count else { return "" }
        return String(letters[value])
    }

    func select(index: Int) {
        selectedIndex = index
    }

    func setValue(_ value: Int?) {
        guard let index = selectedIndex else { return }
        if givenIndices.contains(index) { return }

        if !timerStarted {
            startTimer()
        }
        
        let oldValue = grid.cells[index]
        undoStack.append((index: index, oldValue: oldValue, newValue: value))
        
        if undoStack.count > 100 {
            undoStack.removeFirst()
        }
        
        redoStack.removeAll()
        canUndo = !undoStack.isEmpty
        canRedo = false

        let wasIncorrect = value != nil && value != level.solution.cells[index] && value != oldValue
        grid.cells[index] = value
        if wasIncorrect {
            mistakeCount += 1
            if penaltyModeEnabled {
                elapsedTime += penaltySeconds
            }
        }
        updateWinState()
    }

    func setPenaltyMode(_ enabled: Bool) {
        penaltyModeEnabled = enabled
    }

    func clearSelection() {
        selectedIndex = nil
    }

    func undo() {
        guard let move = undoStack.popLast() else { return }
        grid.cells[move.index] = move.oldValue
        redoStack.append(move)
        canUndo = !undoStack.isEmpty
        canRedo = !redoStack.isEmpty
        updateWinState()
    }

    func redo() {
        guard let move = redoStack.popLast() else { return }
        grid.cells[move.index] = move.newValue
        undoStack.append(move)
        canUndo = !undoStack.isEmpty
        canRedo = !redoStack.isEmpty
        updateWinState()
    }

    private func updateWinState() {
        let wordIndices = forcedIndices
        let wordComplete = wordIndices.allSatisfy { index in
            grid.cells[index] == level.solution.cells[index]
        }
        if wordComplete && !isWordComplete {
            isWordComplete = true
        }
        isComplete = grid.cells == level.solution.cells
        if isComplete {
            stopTimer()
        }
    }

    private func startTimer() {
        guard timer == nil else { return }
        timerStarted = true
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            guard let self else { return }
            self.elapsedTime += 0.1
        }
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    // MARK: - State Persistence
    
    func saveState(levelIndex: Int, difficulty: Difficulty) {
        let state = SavedGameState(
            levelIndex: levelIndex,
            difficulty: difficulty.rawValue,
            cells: grid.cells,
            elapsedTime: elapsedTime,
            mistakeCount: mistakeCount
        )
        if let encoded = try? JSONEncoder().encode(state) {
            UserDefaults.standard.set(encoded, forKey: SavedGameState.storageKey)
        }
    }
    
    func restoreState(from saved: SavedGameState) {
        grid = WordokuGrid(cells: saved.cells)
        elapsedTime = saved.elapsedTime
        mistakeCount = saved.mistakeCount
        updateWinState()
        if !isComplete {
            startTimer()
        }
    }
    
    static func loadSavedState() -> SavedGameState? {
        guard let data = UserDefaults.standard.data(forKey: SavedGameState.storageKey),
              let state = try? JSONDecoder().decode(SavedGameState.self, from: data) else {
            return nil
        }
        return state
    }
    
    static func clearSavedState() {
        UserDefaults.standard.removeObject(forKey: SavedGameState.storageKey)
    }

    deinit {
        stopTimer()
    }
}

struct SavedGameState: Codable {
    static let storageKey = "wordoku.savedGameState"
    
    let levelIndex: Int
    let difficulty: String
    let cells: [Int?]
    let elapsedTime: TimeInterval
    let mistakeCount: Int

    init(levelIndex: Int, difficulty: String, cells: [Int?], elapsedTime: TimeInterval = 0, mistakeCount: Int = 0) {
        self.levelIndex = levelIndex
        self.difficulty = difficulty
        self.cells = cells
        self.elapsedTime = elapsedTime
        self.mistakeCount = mistakeCount
    }

    private enum CodingKeys: String, CodingKey {
        case levelIndex
        case difficulty
        case cells
        case elapsedTime
        case mistakeCount
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        levelIndex = try container.decode(Int.self, forKey: .levelIndex)
        difficulty = try container.decode(String.self, forKey: .difficulty)
        cells = try container.decode([Int?].self, forKey: .cells)
        elapsedTime = try container.decodeIfPresent(TimeInterval.self, forKey: .elapsedTime) ?? 0
        mistakeCount = try container.decodeIfPresent(Int.self, forKey: .mistakeCount) ?? 0
    }
}
