import Foundation
import SwiftUI
import Combine

final class MiniGameViewModel: ObservableObject {
    let level: MiniLevel
    @Published var grid: MiniGrid
    @Published var selectedIndex: Int?
    @Published var showConflicts: Bool = true
    @Published var isComplete: Bool = false
    @Published var isWordComplete: Bool = false
    @Published var canUndo: Bool = false
    @Published var canRedo: Bool = false
    @Published var elapsedTime: TimeInterval = 0
    @Published var mistakeCount: Int = 0

    private var undoStack: [(index: Int, oldValue: Int?, newValue: Int?)] = []
    private var redoStack: [(index: Int, oldValue: Int?, newValue: Int?)] = []
    private var timerStarted = false
    private var timer: Timer?
    private var penaltyModeEnabled = false
    private let penaltySeconds: TimeInterval = 15

    init(level: MiniLevel) {
        self.level = level
        self.grid = level.puzzle
        self.selectedIndex = nil
        self.isComplete = false
        self.isWordComplete = false
        self.canUndo = false
        self.canRedo = false
        self.mistakeCount = 0
        updateWinState()
    }

    var letters: [Character] {
        level.word.letters
    }

    var givenIndices: Set<Int> {
        var indices = Set<Int>()
        for idx in 0..<36 where level.puzzle.cells[idx] != nil {
            indices.insert(idx)
        }
        return indices
    }

    var conflictIndices: Set<Int> {
        guard showConflicts else { return [] }
        return MiniValidator.conflictingIndices(in: grid)
    }

    var forcedIndices: Set<Int> {
        switch level.forcedAxis {
        case .row:
            return Set(MiniGrid.rowIndices(level.forcedIndex))
        case .col:
            return Set(MiniGrid.colIndices(level.forcedIndex))
        case .diagonal, .antiDiagonal:
            return []
        }
    }

    var orderedForcedIndices: [Int] {
        switch level.forcedAxis {
        case .row:
            return MiniGrid.rowIndices(level.forcedIndex)
        case .col:
            return MiniGrid.colIndices(level.forcedIndex)
        case .diagonal, .antiDiagonal:
            return []
        }
    }

    func letter(for value: Int?) -> String {
        guard let value = value, value >= 0, value < letters.count else { return "" }
        return String(letters[value])
    }

    func select(index: Int) {
        selectedIndex = index
    }

    func setValue(_ value: Int?) {
        guard let index = selectedIndex else { return }
        if givenIndices.contains(index) { return }

        if !timerStarted {
            startTimer()
        }

        let oldValue = grid.cells[index]
        undoStack.append((index: index, oldValue: oldValue, newValue: value))

        if undoStack.count > 100 {
            undoStack.removeFirst()
        }

        redoStack.removeAll()
        canUndo = !undoStack.isEmpty
        canRedo = false

        let wasIncorrect = value != nil && value != level.solution.cells[index] && value != oldValue
        grid.cells[index] = value
        if wasIncorrect {
            mistakeCount += 1
            if penaltyModeEnabled {
                elapsedTime += penaltySeconds
            }
        }
        updateWinState()
    }

    func setPenaltyMode(_ enabled: Bool) {
        penaltyModeEnabled = enabled
    }

    func clearSelection() {
        selectedIndex = nil
    }

    func undo() {
        guard let move = undoStack.popLast() else { return }
        grid.cells[move.index] = move.oldValue
        redoStack.append(move)
        canUndo = !undoStack.isEmpty
        canRedo = !redoStack.isEmpty
        updateWinState()
    }

    func redo() {
        guard let move = redoStack.popLast() else { return }
        grid.cells[move.index] = move.newValue
        undoStack.append(move)
        canUndo = !undoStack.isEmpty
        canRedo = !redoStack.isEmpty
        updateWinState()
    }

    private func updateWinState() {
        let wordIndices = forcedIndices
        let wordComplete = wordIndices.allSatisfy { index in
            grid.cells[index] == level.solution.cells[index]
        }
        if wordComplete && !isWordComplete {
            isWordComplete = true
        }
        isComplete = grid.cells == level.solution.cells
        if isComplete {
            stopTimer()
        }
    }

    private func startTimer() {
        guard timer == nil else { return }
        timerStarted = true
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            guard let self else { return }
            self.elapsedTime += 0.1
        }
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    deinit {
        stopTimer()
    }
}
