import Foundation
import SwiftUI
import Combine

final class LevelSelectViewModel: ObservableObject {
    @Published var words: [WordokuWord] = []
    @Published var unlockedCount: Int = 1 {
        didSet { saveProgressIfNeeded() }
    }
    @Published var completedLevels: Set<Int> = [] {
        didSet { saveProgressIfNeeded() }
    }
    @Published var difficulty: Difficulty = .easy {
        didSet {
            guard oldValue != difficulty else { return }
            guard hasLoadedProgress else { return }
            ProgressStore.saveSelectedDifficulty(difficulty)
            loadWordsForDifficulty()
            loadProgressForCurrentDifficulty()
        }
    }
    @Published var errorMessage: String?

    private let loader = WordListLoader()
    private let factory = WordokuLevelFactory()
    private var allWords: [WordokuWord] = []
    private var wordsByDifficulty: [Difficulty: [WordokuWord]] = [:]
    private var hasLoadedProgress = false
    private var isApplyingProgress = false

    init() {
        loadAllWords()
        difficulty = ProgressStore.loadSelectedDifficulty()
        loadWordsForDifficulty()
        loadProgressForCurrentDifficulty()
        hasLoadedProgress = true
        saveProgressIfNeeded()
    }

    var levelCount: Int {
        words.count
    }

    private func loadAllWords() {
        let loadedWords = loader.loadWords()
        var seen = Set<String>()
        allWords = loadedWords.filter { seen.insert($0.raw).inserted }
        if allWords.isEmpty {
            if let fallback = WordokuWord(raw: "ABCDEFGHI") {
                allWords = [fallback]
                errorMessage = "wordlist.txt missing or invalid."
            } else {
                allWords = []
                errorMessage = "No valid words available."
            }
        } else {
            errorMessage = nil
        }
        wordsByDifficulty = WordDifficultyOrdering.partitionedWordsByDifficulty(allWords)
    }

    private func loadWordsForDifficulty() {
        words = wordsByDifficulty[difficulty] ?? allWords
        
        if words.isEmpty {
            unlockedCount = 0
        } else if unlockedCount < 1 {
            unlockedCount = 1
        } else if unlockedCount > words.count {
            unlockedCount = words.count
        }
        completedLevels = Set(completedLevels.filter { $0 < words.count })
    }

    @available(*, deprecated, message: "Use loadAllWords() and loadWordsForDifficulty() instead")
    func loadWords() {
        loadAllWords()
        loadWordsForDifficulty()
    }

    func isLocked(index: Int) -> Bool {
        index >= unlockedCount
    }

    func makeLevel(index: Int) -> WordokuLevel? {
        guard index >= 0, index < words.count else { return nil }
        var rng: RandomNumberGenerator = SeededGenerator(seed: seed(for: index))
        let axes: [ForcedAxis] = [.row, .col, .diagonal, .antiDiagonal]
        let axis = axes[Int(rng.next() % UInt64(axes.count))]
        let forcedIndex = Int(rng.next() % 9)
        return factory.makeLevel(
            word: words[index],
            difficulty: difficulty,
            forcedAxis: axis,
            forcedIndex: forcedIndex,
            rng: &rng
        )
    }

    func markCompleted(index: Int) {
        completedLevels.insert(index)
        let nextUnlocked = min(index + 2, words.count)
        if nextUnlocked > unlockedCount {
            unlockedCount = nextUnlocked
        }
    }

    private func seed(for index: Int) -> UInt64 {
        let diffSeed: UInt64
        switch difficulty {
        case .easy: diffSeed = 1
        case .medium: diffSeed = 2
        case .hard: diffSeed = 3
        }
        return UInt64(index + 1) &* 0x9E3779B97F4A7C15 ^ diffSeed
    }

    private func loadProgressForCurrentDifficulty() {
        let progress = ProgressStore.loadProgress(for: difficulty, levelCount: words.count)
        isApplyingProgress = true
        unlockedCount = progress.unlockedCount
        completedLevels = progress.completedLevels
        isApplyingProgress = false
    }

    private func saveProgressIfNeeded() {
        guard hasLoadedProgress, !isApplyingProgress else { return }
        ProgressStore.saveSelectedDifficulty(difficulty)
        ProgressStore.saveProgress(for: difficulty, unlockedCount: unlockedCount, completedLevels: completedLevels)
    }
}

private enum WordDifficultyOrdering {
    private static let vowelSet = Set("AEIOUY")
    private static let rareLetterSet = Set("QZXJKV")

    static func partitionedWordsByDifficulty(_ words: [WordokuWord]) -> [Difficulty: [WordokuWord]] {
        guard !words.isEmpty else {
            return Difficulty.allCases.reduce(into: [:]) { result, difficulty in
                result[difficulty] = []
            }
        }

        let counts = DifficultyWordDistribution.counts(totalWords: words.count)
        let easiestToHardest = orderedWords(words, for: .easy)

        let easyCount = counts[.easy] ?? 0
        let mediumCount = counts[.medium] ?? 0

        let easyEnd = min(easyCount, easiestToHardest.count)
        let mediumEnd = min(easyEnd + mediumCount, easiestToHardest.count)

        let easySlice = Array(easiestToHardest[0..<easyEnd])
        let mediumSlice = Array(easiestToHardest[easyEnd..<mediumEnd])
        let hardSlice = Array(easiestToHardest[mediumEnd..<easiestToHardest.count])

        return [
            .easy: orderedWords(easySlice, for: .easy),
            .medium: orderedWords(mediumSlice, for: .medium),
            .hard: orderedWords(hardSlice, for: .hard)
        ]
    }

    static func orderedWords(_ words: [WordokuWord], for difficulty: Difficulty) -> [WordokuWord] {
        guard !words.isEmpty else { return [] }
        let scored = words.map { word in
            (word: word, score: complexityScore(for: word.raw))
        }

        switch difficulty {
        case .easy:
            return scored
                .sorted { lhs, rhs in
                    if lhs.score == rhs.score { return lhs.word.raw < rhs.word.raw }
                    return lhs.score < rhs.score
                }
                .map { $0.word }
        case .hard:
            return scored
                .sorted { lhs, rhs in
                    if lhs.score == rhs.score { return lhs.word.raw < rhs.word.raw }
                    return lhs.score > rhs.score
                }
                .map { $0.word }
        case .medium:
            let sortedScores = scored.map { $0.score }.sorted()
            let median = sortedScores[sortedScores.count / 2]
            return scored
                .sorted { lhs, rhs in
                    let leftDistance = abs(lhs.score - median)
                    let rightDistance = abs(rhs.score - median)
                    if leftDistance == rightDistance { return lhs.word.raw < rhs.word.raw }
                    return leftDistance < rightDistance
                }
                .map { $0.word }
        }
    }

    private static func complexityScore(for rawWord: String) -> Double {
        let characters = Array(rawWord)
        let vowelCount = Double(characters.filter { vowelSet.contains($0) }.count)
        let rareCount = Double(characters.filter { rareLetterSet.contains($0) }.count)
        let maxConsonantRun = Double(longestConsonantRun(in: characters))
        let transitions = Double(vowelConsonantTransitions(in: characters))

        let vowelPenalty = abs(vowelCount - 3.5)
        let runPenalty = max(0, maxConsonantRun - 2)
        return (rareCount * 1.9) + (vowelPenalty * 0.8) + (runPenalty * 1.3) - (transitions * 0.2)
    }

    private static func longestConsonantRun(in characters: [Character]) -> Int {
        var best = 0
        var current = 0
        for char in characters {
            if vowelSet.contains(char) {
                current = 0
            } else {
                current += 1
                best = max(best, current)
            }
        }
        return best
    }

    private static func vowelConsonantTransitions(in characters: [Character]) -> Int {
        guard characters.count > 1 else { return 0 }
        var transitions = 0
        for index in 1..<characters.count {
            let previousIsVowel = vowelSet.contains(characters[index - 1])
            let currentIsVowel = vowelSet.contains(characters[index])
            if previousIsVowel != currentIsVowel {
                transitions += 1
            }
        }
        return transitions
    }
}
