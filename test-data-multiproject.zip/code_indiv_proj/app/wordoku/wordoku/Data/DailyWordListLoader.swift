import Foundation
import os.log

/// Errors that can occur when loading daily word lists
public enum DailyWordListLoaderError: Error, LocalizedError {
    case fileNotFound(String)
    case readError(String, Error)
    case noValidWords
    
    public var errorDescription: String? {
        switch self {
        case .fileNotFound(let filename):
            return "Daily word list file '\(filename)' not found in bundle"
        case .readError(let filename, let underlying):
            return "Failed to read '\(filename)': \(underlying.localizedDescription)"
        case .noValidWords:
            return "No valid words found in daily word list"
        }
    }
}

/// Result of loading daily words, including any rejected entries
public struct DailyWordListLoadResult {
    public let words: [WordokuWord]
    public let rejectedCount: Int
    public let totalLines: Int
}

/// Result of loading mini words, including any rejected entries
public struct DailyMiniWordListLoadResult {
    public let words: [MiniWord]
    public let rejectedCount: Int
    public let totalLines: Int
}

public struct DailyWordListLoader {
    public init() {}

    /// Loads phrases from the bundled daily phrases file.
    /// - Parameter bundle: The bundle containing the phrase list (defaults to main bundle)
    /// - Returns: Array of valid WordokuWord objects
    /// - Note: This method logs errors but returns an empty array on failure for graceful degradation
    public func loadPhrases(from bundle: Bundle = .main) -> [WordokuWord] {
        do {
            let result = try loadPhrasesWithDetails(from: bundle)
            return result.words
        } catch {
            WordokuLogger.data.error("Failed to load phrases: \(error.localizedDescription)")
            return []
        }
    }
    
    /// Loads phrases with detailed information about the loading process.
    /// - Parameter bundle: The bundle containing the phrase list
    /// - Returns: DailyWordListLoadResult with words and statistics
    /// - Throws: DailyWordListLoaderError if loading fails
    public func loadPhrasesWithDetails(from bundle: Bundle = .main) throws -> DailyWordListLoadResult {
        let filename = "daily-phrases"
        let ext = "txt"
        
        guard let url = bundle.url(forResource: filename, withExtension: ext) else {
            WordokuLogger.data.error("Daily phrases file not found: \(filename).\(ext)")
            throw DailyWordListLoaderError.fileNotFound("\(filename).\(ext)")
        }
        
        let contents: String
        do {
            contents = try String(contentsOf: url, encoding: .utf8)
            WordokuLogger.data.debug("Successfully read daily phrases file")
        } catch {
            WordokuLogger.data.error("Failed to read daily phrases: \(error.localizedDescription)")
            throw DailyWordListLoaderError.readError("\(filename).\(ext)", error)
        }
        
        let lines = contents.split(whereSeparator: \.isNewline)
        let totalLines = lines.count
        WordokuLogger.data.info("Processing \(totalLines) lines from daily phrases")
        
        var validWords: [WordokuWord] = []
        var rejectedCount = 0
        
        for line in lines {
            let trimmed = String(line).trimmingCharacters(in: .whitespaces)
            // Remove spaces for validation
            let normalized = trimmed.replacingOccurrences(of: " ", with: "")
            if let word = WordokuWord(raw: normalized) {
                validWords.append(word)
            } else if !trimmed.isEmpty {
                rejectedCount += 1
                WordokuLogger.data.debug("Rejected phrase: '\(trimmed)' (invalid format or length)")
            }
        }
        
        WordokuLogger.data.info("Loaded \(validWords.count) valid phrases, rejected \(rejectedCount)")
        
        if validWords.isEmpty {
            WordokuLogger.data.warning("No valid phrases found in daily phrases file")
            throw DailyWordListLoaderError.noValidWords
        }
        
        return DailyWordListLoadResult(
            words: validWords,
            rejectedCount: rejectedCount,
            totalLines: totalLines
        )
    }
    
    /// Loads mini words (6-letter words) from the bundled daily words file.
    /// - Parameter bundle: The bundle containing the mini word list (defaults to main bundle)
    /// - Returns: Array of valid MiniWord objects
    /// - Note: This method logs errors but returns an empty array on failure for graceful degradation
    public func loadMiniWords(from bundle: Bundle = .main) -> [MiniWord] {
        do {
            let result = try loadMiniWordsWithDetails(from: bundle)
            return result.words
        } catch {
            WordokuLogger.data.error("Failed to load mini words: \(error.localizedDescription)")
            return []
        }
    }
    
    /// Loads mini words with detailed information about the loading process.
    /// - Parameter bundle: The bundle containing the mini word list
    /// - Returns: DailyMiniWordListLoadResult with words and statistics
    /// - Throws: DailyWordListLoaderError if loading fails
    public func loadMiniWordsWithDetails(from bundle: Bundle = .main) throws -> DailyMiniWordListLoadResult {
        let filename = "daily-words-6"
        let ext = "txt"
        
        guard let url = bundle.url(forResource: filename, withExtension: ext) else {
            WordokuLogger.data.error("Daily mini words file not found: \(filename).\(ext)")
            throw DailyWordListLoaderError.fileNotFound("\(filename).\(ext)")
        }
        
        let contents: String
        do {
            contents = try String(contentsOf: url, encoding: .utf8)
            WordokuLogger.data.debug("Successfully read daily mini words file")
        } catch {
            WordokuLogger.data.error("Failed to read daily mini words: \(error.localizedDescription)")
            throw DailyWordListLoaderError.readError("\(filename).\(ext)", error)
        }
        
        let lines = contents.split(whereSeparator: \.isNewline)
        let totalLines = lines.count
        WordokuLogger.data.info("Processing \(totalLines) lines from daily mini words")
        
        var validWords: [MiniWord] = []
        var rejectedCount = 0
        
        for line in lines {
            let trimmed = String(line).trimmingCharacters(in: .whitespaces)
            if let word = MiniWord(raw: trimmed) {
                validWords.append(word)
            } else if !trimmed.isEmpty {
                rejectedCount += 1
                WordokuLogger.data.debug("Rejected mini word: '\(trimmed)' (invalid format or length)")
            }
        }
        
        WordokuLogger.data.info("Loaded \(validWords.count) valid mini words, rejected \(rejectedCount)")
        
        if validWords.isEmpty {
            WordokuLogger.data.warning("No valid mini words found in daily mini words file")
            throw DailyWordListLoaderError.noValidWords
        }
        
        return DailyMiniWordListLoadResult(
            words: validWords,
            rejectedCount: rejectedCount,
            totalLines: totalLines
        )
    }
}
