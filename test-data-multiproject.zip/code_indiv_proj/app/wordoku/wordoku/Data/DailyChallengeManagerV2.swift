import Foundation

public enum DailyPuzzleType: String, Codable {
    case phrase
    case mini
}

public enum DailyChallengePuzzleV2: Equatable {
    case phrase(WordokuLevel)
    case mini(MiniLevel)
}

public struct MiniLevel: Equatable {
    public let word: MiniWord
    public let difficulty: Difficulty
    public let puzzle: MiniGrid
    public let solution: MiniGrid
    public let forcedAxis: ForcedAxis
    public let forcedIndex: Int

    public init(word: MiniWord, difficulty: Difficulty, puzzle: MiniGrid, solution: MiniGrid, forcedAxis: ForcedAxis, forcedIndex: Int) {
        self.word = word
        self.difficulty = difficulty
        self.puzzle = puzzle
        self.solution = solution
        self.forcedAxis = forcedAxis
        self.forcedIndex = forcedIndex
    }
}

public struct DailyChallengeManagerV2 {
    private let loader = DailyWordListLoader()
    private let defaults = UserDefaults.standard
    private let calendar = Calendar.current

    private let lastCompletionDateKey = "dailyChallenge.lastCompletionDate"
    private let streakKey = "dailyChallenge.streak"

    public init() {}

    public func todaysPuzzleType() -> DailyPuzzleType {
        todaySeed() % 2 == 0 ? .phrase : .mini
    }

    public func todaysDifficulty() -> Difficulty {
        let rotation: [Difficulty] = [.medium, .hard]
        let index = Int(todaySeed() / 3) % rotation.count
        return rotation[index]
    }

    public func generateTodaysPuzzle() -> DailyChallengePuzzleV2? {
        let difficulty = todaysDifficulty()
        switch todaysPuzzleType() {
        case .phrase:
            guard let level = generateTodaysPhrasePuzzle(difficulty: difficulty) else { return nil }
            return .phrase(level)
        case .mini:
            guard let level = generateTodaysMiniPuzzle(difficulty: difficulty) else { return nil }
            return .mini(level)
        }
    }

    public func generateTodaysPhrasePuzzle(difficulty: Difficulty) -> WordokuLevel? {
        let phrases = loader.loadPhrases()
        guard !phrases.isEmpty else { return nil }

        let seed = todaySeed()
        let word = phrases[Int(seed) % phrases.count]
        let forcedAxis: ForcedAxis = .row
        let forcedIndex = 0

        var rng: any RandomNumberGenerator = SeededGenerator(seed: seed)
        let solutionGenerator = WordokuSolutionGenerator()
        guard let solution = solutionGenerator.generateSolution(
            word: word,
            forcedAxis: forcedAxis,
            forcedIndex: forcedIndex,
            rng: &rng
        ) else {
            return nil
        }

        let puzzle = WordokuPuzzleGenerator().generatePuzzle(from: solution, difficulty: difficulty, rng: &rng)
        return WordokuLevel(
            word: word,
            difficulty: difficulty,
            puzzle: puzzle,
            solution: solution,
            forcedAxis: forcedAxis,
            forcedIndex: forcedIndex
        )
    }

    public func generateTodaysMiniPuzzle(difficulty: Difficulty) -> MiniLevel? {
        let words = loader.loadMiniWords()
        guard !words.isEmpty else { return nil }

        let seed = todaySeed()
        let word = words[Int(seed) % words.count]
        let forcedAxis: ForcedAxis = .row
        let forcedIndex = 0

        var rng: any RandomNumberGenerator = SeededGenerator(seed: seed)
        let solutionGenerator = MiniSolutionGenerator()
        guard let solution = solutionGenerator.generateSolution(
            word: word,
            forcedAxis: forcedAxis,
            forcedIndex: forcedIndex,
            rng: &rng
        ) else {
            return nil
        }

        let puzzle = MiniPuzzleGenerator().generatePuzzle(from: solution, difficulty: difficulty, rng: &rng)
        return MiniLevel(
            word: word,
            difficulty: difficulty,
            puzzle: puzzle,
            solution: solution,
            forcedAxis: forcedAxis,
            forcedIndex: forcedIndex
        )
    }

    public func markTodayComplete(time: TimeInterval, type: DailyPuzzleType) {
        let now = Date()
        let previousCompletionDate = defaults.object(forKey: lastCompletionDateKey) as? Date

        if let previousCompletionDate,
           calendar.isDate(previousCompletionDate, inSameDayAs: now) {
            savePersonalBest(time: time, type: type)
            return
        }

        let updatedStreak: Int
        if let previousCompletionDate {
            let dayDelta = daysDifference(from: previousCompletionDate, to: now)
            if dayDelta == 1 {
                updatedStreak = getCurrentStreak() + 1
            } else {
                updatedStreak = 1
            }
        } else {
            updatedStreak = 1
        }

        defaults.set(now, forKey: lastCompletionDateKey)
        defaults.set(updatedStreak, forKey: streakKey)
        savePersonalBest(time: time, type: type)
    }

    public func isTodayComplete() -> Bool {
        guard let date = defaults.object(forKey: lastCompletionDateKey) as? Date else {
            return false
        }
        return calendar.isDateInToday(date)
    }

    public func getCurrentStreak() -> Int {
        defaults.object(forKey: streakKey) as? Int ?? 0
    }

    public func getPersonalBest(for type: DailyPuzzleType) -> TimeInterval? {
        let key = personalBestKey(for: type)
        guard defaults.object(forKey: key) != nil else {
            return nil
        }
        return defaults.double(forKey: key)
    }

    private func savePersonalBest(time: TimeInterval, type: DailyPuzzleType) {
        let key = personalBestKey(for: type)
        if let existing = defaults.object(forKey: key) as? TimeInterval,
           existing <= time {
            return
        }
        defaults.set(time, forKey: key)
    }

    private func personalBestKey(for type: DailyPuzzleType) -> String {
        "dailyChallenge.personalBest.\(type.rawValue)"
    }

    private func todaySeed() -> UInt64 {
        let now = Date()
        let components = calendar.dateComponents([.year, .month, .day], from: now)
        let year = UInt64(components.year ?? 2026)
        let month = UInt64(components.month ?? 1)
        let day = UInt64(components.day ?? 1)
        return year * 10000 + month * 100 + day
    }

    private func daysDifference(from date1: Date, to date2: Date) -> Int {
        let startOfDate1 = calendar.startOfDay(for: date1)
        let startOfDate2 = calendar.startOfDay(for: date2)
        return calendar.dateComponents([.day], from: startOfDate1, to: startOfDate2).day ?? 0
    }
}
