import Foundation

enum DifficultyWordDistribution {
    static func counts(totalWords: Int) -> [Difficulty: Int] {
        let safeTotal = max(0, totalWords)
        let baseCount = safeTotal / Difficulty.allCases.count
        let remainder = safeTotal % Difficulty.allCases.count

        var result: [Difficulty: Int] = [:]
        for (index, difficulty) in Difficulty.allCases.enumerated() {
            let extra = index < remainder ? 1 : 0
            result[difficulty] = baseCount + extra
        }
        return result
    }
}

struct DifficultyProgress {
    let unlockedCount: Int
    let completedLevels: Set<Int>
}

struct ProgressSummary {
    let easyLevelCount: Int
    let mediumLevelCount: Int
    let hardLevelCount: Int
    let easyCompleted: Int
    let mediumCompleted: Int
    let hardCompleted: Int

    var totalCompleted: Int {
        easyCompleted + mediumCompleted + hardCompleted
    }

    var totalAvailable: Int {
        easyLevelCount + mediumLevelCount + hardLevelCount
    }
}

enum ProgressStore {
    private static let defaults = UserDefaults.standard
    private static let selectedDifficultyKey = "wordoku.difficulty"

    static func loadSelectedDifficulty() -> Difficulty {
        guard let raw = defaults.string(forKey: selectedDifficultyKey),
              let difficulty = Difficulty(rawValue: raw) else {
            return .easy
        }
        return difficulty
    }

    static func saveSelectedDifficulty(_ difficulty: Difficulty) {
        defaults.set(difficulty.rawValue, forKey: selectedDifficultyKey)
    }

    static func loadProgress(for difficulty: Difficulty, levelCount: Int) -> DifficultyProgress {
        guard levelCount > 0 else {
            return DifficultyProgress(unlockedCount: 0, completedLevels: [])
        }

        let unlockedKey = unlockedCountKey(for: difficulty)
        let completedKey = completedLevelsKey(for: difficulty)
        let rawUnlocked = defaults.object(forKey: unlockedKey) as? Int ?? 1
        let rawCompleted = defaults.array(forKey: completedKey) as? [Int] ?? []

        let unlockedCount = min(max(rawUnlocked, 1), levelCount)
        let completedLevels = Set(rawCompleted.filter { $0 >= 0 && $0 < levelCount })
        return DifficultyProgress(unlockedCount: unlockedCount, completedLevels: completedLevels)
    }

    static func saveProgress(for difficulty: Difficulty, unlockedCount: Int, completedLevels: Set<Int>) {
        defaults.set(unlockedCount, forKey: unlockedCountKey(for: difficulty))
        defaults.set(Array(completedLevels).sorted(), forKey: completedLevelsKey(for: difficulty))
    }

    static func savePersonalBest(level: Int, difficulty: Difficulty, time: TimeInterval) {
        let key = personalBestKey(level: level, difficulty: difficulty)
        if let existing = defaults.object(forKey: key) as? TimeInterval, existing <= time {
            return
        }
        defaults.set(time, forKey: key)
    }

    static func loadPersonalBest(level: Int, difficulty: Difficulty) -> TimeInterval? {
        let key = personalBestKey(level: level, difficulty: difficulty)
        guard defaults.object(forKey: key) != nil else {
            return nil
        }
        return defaults.double(forKey: key)
    }

    static func resetLevelProgress(level: Int, difficulty: Difficulty) {
        let progress = loadProgress(for: difficulty, levelCount: Int.max)
        var updatedCompletedLevels = progress.completedLevels
        updatedCompletedLevels.remove(level)
        saveProgress(for: difficulty, unlockedCount: progress.unlockedCount, completedLevels: updatedCompletedLevels)
        defaults.removeObject(forKey: personalBestKey(level: level, difficulty: difficulty))
    }

    static func loadSummary(levelCount: Int) -> ProgressSummary {
        let counts = DifficultyWordDistribution.counts(totalWords: levelCount)
        let easyCount = counts[.easy] ?? 0
        let mediumCount = counts[.medium] ?? 0
        let hardCount = counts[.hard] ?? 0

        let easy = loadProgress(for: .easy, levelCount: easyCount)
        let medium = loadProgress(for: .medium, levelCount: mediumCount)
        let hard = loadProgress(for: .hard, levelCount: hardCount)
        return ProgressSummary(
            easyLevelCount: easyCount,
            mediumLevelCount: mediumCount,
            hardLevelCount: hardCount,
            easyCompleted: easy.completedLevels.count,
            mediumCompleted: medium.completedLevels.count,
            hardCompleted: hard.completedLevels.count
        )
    }

    private static func unlockedCountKey(for difficulty: Difficulty) -> String {
        "wordoku.unlockedCount.\(difficulty.rawValue)"
    }

    private static func completedLevelsKey(for difficulty: Difficulty) -> String {
        "wordoku.completedLevels.\(difficulty.rawValue)"
    }

    private static func personalBestKey(level: Int, difficulty: Difficulty) -> String {
        "wordoku.personalBest.\(difficulty.rawValue).\(level)"
    }

    static func resetAllProgress() {
        for difficulty in Difficulty.allCases {
            defaults.removeObject(forKey: unlockedCountKey(for: difficulty))
            defaults.removeObject(forKey: completedLevelsKey(for: difficulty))
        }
        defaults.removeObject(forKey: selectedDifficultyKey)
        
        let allKeys = defaults.dictionaryRepresentation().keys
        for key in allKeys where key.hasPrefix("wordoku.wordIntroSeen.") {
            defaults.removeObject(forKey: key)
        }
        for key in allKeys where key.hasPrefix("wordoku.savedGame") {
            defaults.removeObject(forKey: key)
        }
        for key in allKeys where key.hasPrefix("wordoku.personalBest.") {
            defaults.removeObject(forKey: key)
        }
    }
}
