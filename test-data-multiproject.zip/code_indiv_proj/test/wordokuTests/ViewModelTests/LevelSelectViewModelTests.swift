import XCTest
@testable import wordoku

final class LevelSelectViewModelTests: XCTestCase {
    private static var retainedViewModels: [LevelSelectViewModel] = []

    private func makeViewModel() -> LevelSelectViewModel {
        let viewModel = LevelSelectViewModel()
        Self.retainedViewModels.append(viewModel)
        return viewModel
    }

    override class func tearDown() {
        retainedViewModels.removeAll()
        super.tearDown()
    }
    
    override func setUpWithError() throws {
        let defaults = UserDefaults.standard
        let keys = defaults.dictionaryRepresentation().keys
        for key in keys where key.hasPrefix("wordoku.unlockedCount.") || key.hasPrefix("wordoku.completedLevels.") {
            defaults.removeObject(forKey: key)
        }
        defaults.removeObject(forKey: "wordoku.difficulty")
    }
    
    override func tearDownWithError() throws {
        let defaults = UserDefaults.standard
        let keys = defaults.dictionaryRepresentation().keys
        for key in keys where key.hasPrefix("wordoku.unlockedCount.") || key.hasPrefix("wordoku.completedLevels.") {
            defaults.removeObject(forKey: key)
        }
        defaults.removeObject(forKey: "wordoku.difficulty")
    }
    
    func testInitialState() {
        let viewModel = makeViewModel()
        
        // Initial unlocked count should be 1
        XCTAssertGreaterThanOrEqual(viewModel.unlockedCount, 1)
        // Completed levels should be empty initially
        XCTAssertTrue(viewModel.completedLevels.isEmpty)
        // Default difficulty should be easy
        XCTAssertEqual(viewModel.difficulty, .easy)
    }
    
    func testMarkCompleted() {
        let viewModel = makeViewModel()
        
        // Complete level 0
        viewModel.markCompleted(index: 0)
        
        XCTAssertTrue(viewModel.completedLevels.contains(0))
        // Unlocked count should increase to 2
        XCTAssertGreaterThanOrEqual(viewModel.unlockedCount, 2)
    }
    
    func testMarkCompletedUnlocksNextLevel() {
        let viewModel = makeViewModel()
        
        // Initial state
        let initialUnlocked = viewModel.unlockedCount
        
        // Complete level 0
        viewModel.markCompleted(index: 0)
        
        // Should unlock at least one more level
        XCTAssertGreaterThan(viewModel.unlockedCount, initialUnlocked)
    }
    
    func testIsLocked() {
        let viewModel = makeViewModel()
        
        // Level 0 should be unlocked
        XCTAssertFalse(viewModel.isLocked(index: 0))
        
        // Levels beyond unlockedCount should be locked
        if viewModel.levelCount > viewModel.unlockedCount {
            XCTAssertTrue(viewModel.isLocked(index: viewModel.unlockedCount))
        }
    }
    
    func testDifficultyPersistence() {
        let viewModel1 = makeViewModel()
        viewModel1.difficulty = .hard
        
        let viewModel2 = makeViewModel()
        XCTAssertEqual(viewModel2.difficulty, .hard)
    }
    
    func testCompletedLevelsPersistence() {
        let viewModel1 = makeViewModel()
        viewModel1.markCompleted(index: 0)
        
        let viewModel2 = makeViewModel()
        XCTAssertTrue(viewModel2.completedLevels.contains(0))
    }
    
    func testMakeLevelReturnsLevel() {
        let viewModel = makeViewModel()
        
        // If words are loaded, makeLevel should return a level
        if viewModel.levelCount > 0 {
            let level = viewModel.makeLevel(index: 0)
            XCTAssertNotNil(level)
        }
    }
    
    func testMakeLevelOutOfBounds() {
        let viewModel = makeViewModel()
        
        // Should return nil for invalid indices
        XCTAssertNil(viewModel.makeLevel(index: -1))
        XCTAssertNil(viewModel.makeLevel(index: 1000))
    }
    
    func testLevelCountMatchesWords() {
        let viewModel = makeViewModel()
        
        XCTAssertEqual(viewModel.levelCount, viewModel.words.count)
    }
    
    func testDeterministicLevelGeneration() throws {
        let viewModel = makeViewModel()
        
        guard viewModel.levelCount > 0 else {
            throw XCTSkip("No words loaded")
        }
        
        // Same index and difficulty should produce the same level
        let level1 = viewModel.makeLevel(index: 0)
        let level2 = viewModel.makeLevel(index: 0)
        
        XCTAssertEqual(level1?.puzzle.cells, level2?.puzzle.cells)
        XCTAssertEqual(level1?.solution.cells, level2?.solution.cells)
    }
    
    func testDifferentDifficultyProducesDifferentLevel() throws {
        let viewModel = makeViewModel()
        
        guard viewModel.levelCount > 0 else {
            throw XCTSkip("No words loaded")
        }
        
        viewModel.difficulty = .easy
        let easyLevel = viewModel.makeLevel(index: 0)
        
        viewModel.difficulty = .hard
        let hardLevel = viewModel.makeLevel(index: 0)
        
        // Different difficulties should have different numbers of given cells
        let easyGivens = easyLevel?.puzzle.givenCount() ?? 0
        let hardGivens = hardLevel?.puzzle.givenCount() ?? 0
        
        // Easy should have more givens than hard
        XCTAssertGreaterThan(easyGivens, hardGivens)
    }

    func testWordlistWordsAreSplitAcrossDifficulties() throws {
        let loader = WordListLoader()
        let expectedWords = Set(loader.loadWords().map(\.raw))
        guard !expectedWords.isEmpty else {
            throw XCTSkip("No words loaded")
        }

        let expectedCounts = DifficultyWordDistribution.counts(totalWords: expectedWords.count)

        let viewModel = makeViewModel()
        var aggregateVisibleWords: Set<String> = []

        for level in Difficulty.allCases {
            viewModel.difficulty = level
            let visibleWords = Set(viewModel.words.map(\.raw))
            aggregateVisibleWords.formUnion(visibleWords)
            XCTAssertEqual(viewModel.words.count, expectedCounts[level])
        }

        XCTAssertEqual(aggregateVisibleWords, expectedWords)
    }

    func testDifficultyOrderingUsesDifferentWordPatterns() throws {
        let viewModel = makeViewModel()
        guard viewModel.levelCount > 5 else {
            throw XCTSkip("Not enough words loaded")
        }

        viewModel.difficulty = .easy
        let easyOrder = viewModel.words.map(\.raw)

        viewModel.difficulty = .hard
        let hardOrder = viewModel.words.map(\.raw)

        XCTAssertNotEqual(easyOrder, hardOrder)
    }
}
