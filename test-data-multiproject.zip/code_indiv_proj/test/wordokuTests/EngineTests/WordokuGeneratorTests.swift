import XCTest
@testable import wordoku

final class WordokuGeneratorTests: XCTestCase {
    func testGeneratedPuzzleHasUniqueSolution() {
        guard let word = WordokuWord(raw: "ABCDEFGHI") else {
            XCTFail("Invalid test word")
            return
        }
        var rng: RandomNumberGenerator = SeededGenerator(seed: 42)
        let factory = WordokuLevelFactory()
        guard let level = factory.makeLevel(word: word, difficulty: .easy, forcedAxis: .row, forcedIndex: 0, rng: &rng) else {
            XCTFail("Failed to generate level")
            return
        }
        let solver = WordokuSolver()
        XCTAssertEqual(solver.countSolutions(level.puzzle, limit: 2), 1)
    }

    func testForcedRowPresentInSolution() {
        guard let word = WordokuWord(raw: "ABCDEFGHI") else {
            XCTFail("Invalid test word")
            return
        }
        var rng: RandomNumberGenerator = SeededGenerator(seed: 99)
        let factory = WordokuLevelFactory()
        guard let level = factory.makeLevel(word: word, difficulty: .easy, forcedAxis: .row, forcedIndex: 0, rng: &rng) else {
            XCTFail("Failed to generate level")
            return
        }
        let rowIndices = WordokuGrid.rowIndices(0)
        let rowValues = rowIndices.compactMap { level.solution.cells[$0] }
        XCTAssertEqual(rowValues, Array(0..<9))
    }

    func testPuzzleSymmetryAndBoxMinimums() {
        guard let word = WordokuWord(raw: "ABCDEFGHI") else {
            XCTFail("Invalid test word")
            return
        }
        var rng: RandomNumberGenerator = SeededGenerator(seed: 123)
        let factory = WordokuLevelFactory()
        guard let level = factory.makeLevel(word: word, difficulty: .medium, forcedAxis: .row, forcedIndex: 0, rng: &rng) else {
            XCTFail("Failed to generate level")
            return
        }
        let puzzle = level.puzzle
        for index in 0..<81 {
            let pair = 80 - index
            XCTAssertEqual(puzzle.cells[index] == nil, puzzle.cells[pair] == nil)
        }
        let minPerBox = Difficulty.medium.minGivensPerBox
        for box in 0..<9 {
            let count = WordokuGrid.boxIndices(box).reduce(0) { total, idx in
                total + (puzzle.cells[idx] == nil ? 0 : 1)
            }
            XCTAssertGreaterThanOrEqual(count, minPerBox)
        }
    }

    func testStarterPuzzleContainsEveryLetterAtLeastOnce() {
        guard let word = WordokuWord(raw: "ABCDEFGHI") else {
            XCTFail("Invalid test word")
            return
        }

        var rng: RandomNumberGenerator = SeededGenerator(seed: 333)
        let factory = WordokuLevelFactory()
        guard let level = factory.makeLevel(word: word, difficulty: .hard, forcedAxis: .row, forcedIndex: 0, rng: &rng) else {
            XCTFail("Failed to generate level")
            return
        }

        let present = Set(level.puzzle.cells.compactMap { $0 })
        XCTAssertEqual(present.count, 9)
        XCTAssertEqual(present, Set(0..<9))
    }

    func testGeneratorBatchStaysUnderTimeoutBudget() {
        guard let word = WordokuWord(raw: "ABCDEFGHI") else {
            XCTFail("Invalid test word")
            return
        }

        let budgetSeconds: TimeInterval = 6.0
        let start = Date()
        let factory = WordokuLevelFactory()

        for seed in 0..<12 {
            var rng: RandomNumberGenerator = SeededGenerator(seed: UInt64(seed + 500))
            let difficulty: Difficulty = seed % 2 == 0 ? .medium : .hard
            let forcedAxis: ForcedAxis = seed % 3 == 0 ? .row : .col
            let forcedIndex = seed % 9
            let level = factory.makeLevel(
                word: word,
                difficulty: difficulty,
                forcedAxis: forcedAxis,
                forcedIndex: forcedIndex,
                rng: &rng
            )
            XCTAssertNotNil(level)
        }

        let elapsed = Date().timeIntervalSince(start)
        XCTAssertLessThan(elapsed, budgetSeconds, "Generator batch exceeded timeout budget")
    }
}
