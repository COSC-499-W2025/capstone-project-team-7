import XCTest
@testable import wordoku

final class WordokuSolverTests: XCTestCase {
    func testSolverFindsSolution() {
        let puzzle: [Int?] = [
            4, 2, nil, nil, 6, nil, nil, nil, nil,
            5, nil, nil, 0, 8, 4, nil, nil, nil,
            nil, 8, 7, nil, nil, nil, nil, 5, nil,
            7, nil, nil, nil, 5, nil, nil, nil, 2,
            3, nil, nil, 7, nil, 2, nil, nil, 0,
            6, nil, nil, nil, 1, nil, nil, nil, 5,
            nil, 5, nil, nil, nil, nil, 1, 7, nil,
            nil, nil, nil, 3, 0, 8, nil, nil, 4,
            nil, nil, nil, nil, 7, nil, nil, 6, 8
        ]
        let solution: [Int?] = [
            4, 2, 3, 5, 6, 7, 8, 0, 1,
            5, 6, 1, 0, 8, 4, 2, 3, 7,
            0, 8, 7, 2, 3, 1, 4, 5, 6,
            7, 4, 8, 6, 5, 0, 3, 1, 2,
            3, 1, 5, 7, 4, 2, 6, 8, 0,
            6, 0, 2, 8, 1, 3, 7, 4, 5,
            8, 5, 0, 4, 2, 6, 1, 7, 3,
            1, 7, 6, 3, 0, 8, 5, 2, 4,
            2, 3, 4, 1, 7, 5, 0, 6, 8
        ]
        let solver = WordokuSolver()
        let solved = solver.solve(WordokuGrid(cells: puzzle))
        XCTAssertEqual(solved?.cells, solution)
    }

    func testSolutionCounterStopsAtTwo() {
        let solver = WordokuSolver()
        let count = solver.countSolutions(WordokuGrid(), limit: 2)
        XCTAssertEqual(count, 2)
    }

    func testSolverHardRegressionPuzzle() {
        let hardPuzzle: [Int?] = [
            7, nil, nil, nil, nil, nil, nil, nil, nil,
            nil, nil, 2, 5, nil, nil, nil, nil, nil,
            nil, 6, nil, nil, 8, nil, 1, nil, nil,
            nil, 4, nil, nil, nil, 6, nil, nil, nil,
            nil, nil, nil, nil, 3, 4, 6, nil, nil,
            nil, nil, nil, 0, nil, nil, nil, 2, nil,
            nil, nil, 0, nil, nil, nil, nil, 5, 7,
            nil, nil, 7, 4, nil, nil, nil, 0, nil,
            nil, 8, nil, nil, nil, nil, 3, nil, nil,
        ]

        let expectedSolution: [Int?] = [
            7, 0, 1, 6, 4, 2, 5, 3, 8,
            8, 3, 2, 5, 7, 1, 0, 6, 4,
            5, 6, 4, 3, 8, 0, 1, 7, 2,
            0, 4, 3, 1, 2, 6, 7, 8, 5,
            2, 5, 8, 7, 3, 4, 6, 1, 0,
            1, 7, 6, 0, 5, 8, 4, 2, 3,
            4, 1, 0, 8, 6, 3, 2, 5, 7,
            3, 2, 7, 4, 1, 5, 8, 0, 6,
            6, 8, 5, 2, 0, 7, 3, 4, 1,
        ]

        let solver = WordokuSolver()
        let solved = solver.solve(WordokuGrid(cells: hardPuzzle))
        XCTAssertEqual(solved?.cells, expectedSolution)
    }

    func testSolverEvilRegressionPuzzle() {
        let evilPuzzle: [Int?] = [
            0, nil, nil, nil, nil, 6, nil, 8, nil,
            nil, 2, nil, nil, 1, nil, nil, nil, 7,
            nil, nil, 8, 5, nil, nil, 4, nil, nil,
            nil, nil, 4, 2, nil, nil, 8, nil, nil,
            nil, 0, nil, nil, 7, nil, nil, nil, 1,
            5, nil, nil, nil, nil, 3, nil, nil, nil,
            2, nil, nil, nil, nil, nil, nil, 0, nil,
            nil, 3, nil, nil, nil, nil, nil, nil, 6,
            nil, nil, 6, nil, nil, nil, 2, nil, nil,
        ]

        let expectedSolution: [Int?] = [
            0, 5, 1, 7, 4, 6, 3, 8, 2,
            4, 2, 3, 0, 1, 8, 5, 6, 7,
            6, 7, 8, 5, 3, 2, 4, 1, 0,
            3, 6, 4, 2, 0, 1, 8, 7, 5,
            8, 0, 2, 4, 7, 5, 6, 3, 1,
            5, 1, 7, 6, 8, 3, 0, 2, 4,
            2, 4, 5, 3, 6, 7, 1, 0, 8,
            1, 3, 0, 8, 2, 4, 7, 5, 6,
            7, 8, 6, 1, 5, 0, 2, 4, 3,
        ]

        let solver = WordokuSolver()
        let solved = solver.solve(WordokuGrid(cells: evilPuzzle))
        XCTAssertEqual(solved?.cells, expectedSolution)
    }
}
