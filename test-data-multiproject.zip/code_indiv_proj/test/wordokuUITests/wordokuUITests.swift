import XCTest

final class wordokuUITests: XCTestCase {
    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    @MainActor
    func testDailyChallengeInputRendersImmediately() throws {
        let app = XCUIApplication()
        app.launchArguments.append("-ui-testing-reset")
        app.launch()

        tapElement(app: app, identifier: "main_daily_card", fallbackText: "Daily Challenge")

        let editableCell = firstEditableCell(in: app)
        XCTAssertTrue(editableCell.waitForExistence(timeout: 8))
        let before = editableCell.label
        editableCell.tap()
        editableCell.tap()

        let paletteButton = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'palette_' AND identifier != 'palette_delete'"))
            .firstMatch
        XCTAssertTrue(paletteButton.waitForExistence(timeout: 8))
        paletteButton.tap()

        let didChange = waitForCellLabelChange(editableCell, previous: before, timeout: 3)
        XCTAssertTrue(didChange || app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'cell_' AND label CONTAINS 'Letter'")).count > 0)
    }

    @MainActor
    func testTimerPersistsWhenLeavingAndReturningLevel() throws {
        let app = XCUIApplication()
        app.launchArguments.append("-ui-testing-reset")
        app.launch()

        navigateToFirstLevel(in: app)

        let timer = app.staticTexts["game_timer"]
        if !timer.waitForExistence(timeout: 8) {
            tapLevelOneCard(in: app)
        }
        XCTAssertTrue(timer.waitForExistence(timeout: 8))

        let editableCell = firstEditableCell(in: app)
        XCTAssertTrue(editableCell.waitForExistence(timeout: 8))
        editableCell.tap()
        editableCell.tap()

        let paletteButton = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'palette_' AND identifier != 'palette_delete'"))
            .firstMatch
        XCTAssertTrue(paletteButton.waitForExistence(timeout: 8))
        paletteButton.tap()

        sleep(2)
        let secondsBeforeExit = timerSeconds(from: timer.label)
        XCTAssertNotNil(secondsBeforeExit)
        XCTAssertGreaterThanOrEqual(secondsBeforeExit ?? 0, 1)

        tapBackButton(in: app)
        let isBackOnLevelList = app.staticTexts["DIFFICULTY"].waitForExistence(timeout: 8) || app.otherElements["level_card_1"].waitForExistence(timeout: 8)
        XCTAssertTrue(isBackOnLevelList)
        tapLevelOneCard(in: app)

        let resumedTimer = app.staticTexts["game_timer"]
        XCTAssertTrue(resumedTimer.waitForExistence(timeout: 8))
        let resumedSeconds = timerSeconds(from: resumedTimer.label)
        XCTAssertNotNil(resumedSeconds)
        if let secondsBeforeExit, let resumedSeconds {
            XCTAssertGreaterThanOrEqual(resumedSeconds, max(0, secondsBeforeExit - 1))
        }
    }

    @MainActor
    func testLevelCardsShowGenericLevelLabelBeforeCompletion() throws {
        let app = XCUIApplication()
        app.launchArguments.append("-ui-testing-reset")
        app.launch()

        tapElement(app: app, identifier: "main_continue_card", fallbackText: "Continue Playing")

        let levelLabelExists = app.staticTexts["Level 1"].waitForExistence(timeout: 12)
        let cardExists = app.otherElements["level_card_1"].exists || app.buttons["level_card_1"].exists
        XCTAssertTrue(levelLabelExists || cardExists)
    }

    @MainActor
    func testSettingsPersistForLiquidGlass() throws {
        let app = XCUIApplication()
        app.launchArguments.append("-ui-testing-reset")
        app.launch()

        openSettings(in: app)

        let liquidGlass = app.switches["Liquid Glass Effects"]
        XCTAssertTrue(liquidGlass.waitForExistence(timeout: 5))
        let original = liquidGlass.value as? String ?? "0"
        liquidGlass.tap()
        var toggled = liquidGlass.value as? String ?? "0"
        if original == toggled {
            app.staticTexts["Liquid Glass Effects"].firstMatch.tap()
            toggled = liquidGlass.value as? String ?? "0"
        }

        app.navigationBars.buttons.firstMatch.tap()
        openSettings(in: app)

        let persisted = app.switches["settings_liquid_glass"]
        XCTAssertTrue(persisted.waitForExistence(timeout: 5) || app.switches["Liquid Glass Effects"].waitForExistence(timeout: 5))
        let persistedSwitch = app.switches["settings_liquid_glass"].exists ? app.switches["settings_liquid_glass"] : app.switches["Liquid Glass Effects"]
        XCTAssertEqual(persistedSwitch.value as? String, toggled)
    }

    @MainActor
    func testLaunchPerformance() throws {
        measure(metrics: [XCTApplicationLaunchMetric()]) {
            XCUIApplication().launch()
        }
    }

    private func firstEditableCell(in app: XCUIApplication) -> XCUIElement {
        app.buttons.matching(
            NSPredicate(format: "identifier BEGINSWITH 'cell_' AND label CONTAINS 'Empty'")
        ).firstMatch
    }

    private func navigateToFirstLevel(in app: XCUIApplication) {
        tapElement(app: app, identifier: "main_continue_card", fallbackText: "Continue Playing")

        tapLevelOneCard(in: app)
    }

    private func tapLevelOneCard(in app: XCUIApplication) {
        let card = app.otherElements["level_card_1"]
        if card.waitForExistence(timeout: 5) {
            card.tap()
            return
        }

        let buttonCard = app.buttons["level_card_1"]
        if buttonCard.waitForExistence(timeout: 5) {
            buttonCard.tap()
            return
        }

        let levelLabel = app.staticTexts["Level 1"].firstMatch
        XCTAssertTrue(levelLabel.waitForExistence(timeout: 8))
        levelLabel.tap()
    }

    private func tapBackButton(in app: XCUIApplication) {
        let backCandidates = ["Back", "Continue Playing", "Daily Challenge", "Settings"]
        for label in backCandidates {
            let button = app.navigationBars.buttons[label]
            if button.exists {
                button.tap()
                return
            }
        }

        app.navigationBars.buttons.firstMatch.tap()
    }

    private func timerSeconds(from label: String) -> Int? {
        let parts = label.split(separator: ":")
        guard parts.count == 2,
              let minutes = Int(parts[0]),
              let seconds = Int(parts[1]) else {
            return nil
        }
        return minutes * 60 + seconds
    }

    private func waitForCellLabelChange(_ cell: XCUIElement, previous: String, timeout: TimeInterval) -> Bool {
        let predicate = NSPredicate(format: "label != %@", previous)
        let expectation = XCTNSPredicateExpectation(predicate: predicate, object: cell)
        return XCTWaiter().wait(for: [expectation], timeout: timeout) == .completed
    }

    private func openSettings(in app: XCUIApplication) {
        tapElement(app: app, identifier: "main_settings_card", fallbackText: "Settings")
    }

    private func tapElement(app: XCUIApplication, identifier: String, fallbackText: String) {
        let button = app.buttons[identifier]
        if button.waitForExistence(timeout: 5) {
            button.tap()
            return
        }

        let other = app.otherElements[identifier]
        if other.waitForExistence(timeout: 5) {
            other.tap()
            return
        }

        app.staticTexts[fallbackText].firstMatch.tap()
    }
}
