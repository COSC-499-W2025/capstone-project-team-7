# Wordoku - Remaining Next Steps

All in-app engineering backlog work is implemented and verified in automated tests.

## Feb 27 gameplay bugfix tracker

1. Remove tile/title option from Settings - FIXED
   - Removed title color option and all `settings.titleColorIndex` usage so it no longer affects app UI.
2. Word meaning screen not appearing after finding word - FIXED
   - Auto-trigger now runs when the hidden word is completed (not only when the full puzzle is completed).
3. Move "Show conflicts" from level gameplay controls into Settings - FIXED
   - Removed in-level toggle and added persistent `Show Conflicts` setting.
4. Timer/progress reset after typing, quitting, reopening - FIXED
   - Added autosave on cell/mistake changes, app lifecycle transitions, and periodic in-level snapshots.
   - Added level-exit state handoff refresh so Level Select always reloads the latest saved timer before reopening a level.

## Completed checks
- Full suite passed: `/Users/joaquinalmora/Library/Developer/Xcode/DerivedData/wordoku-dbuutxwedkgwrdbqhbjihpgwbscy/Logs/Test/Test-wordoku-2026.02.25_10-10-54--0800.xcresult`
- Test status: `TEST SUCCEEDED` (61 tests, 0 failures)
- Release archive succeeded: `/Users/joaquinalmora/Desktop/word-sudoku/build/wordoku.xcarchive`
- Versioning already set in `wordoku/wordoku.xcodeproj/project.pbxproj` (`MARKETING_VERSION = 1.0`, `CURRENT_PROJECT_VERSION = 1`)
- App icon set includes the iOS marketing icon entry (`1024x1024`) in `wordoku/wordoku/Assets.xcassets/AppIcon.appiconset/Contents.json`
- Privacy API usage audit completed: only `UserDefaults` required-reason API detected, matching `wordoku/wordoku/PrivacyInfo.xcprivacy`
- Manual QA checklist pre-filled with automated evidence in `MANUAL_QA_CHECKLIST.md`

## Execution docs
- Manual QA checklist: `MANUAL_QA_CHECKLIST.md`
- App Store metadata and privacy answers template: `APP_STORE_CONNECT_TEMPLATE.md`
- TestFlight and submission runbook: `TESTFLIGHT_RUNBOOK.md`

## Remaining work before App Store release
1. Fill App Store metadata and policy fields in App Store Connect
   - Use `APP_STORE_CONNECT_TEMPLATE.md` and finalize product copy, keywords, URLs, and age rating
2. Run manual QA and record evidence
   - Execute remaining manual-only scenarios in `MANUAL_QA_CHECKLIST.md` (rows marked `PENDING (Manual)`)
   - Capture pass/fail and screenshot/video evidence for any failures
3. Upload App Store assets
   - Upload localized screenshots/previews for required device classes
   - Add support URL, privacy policy URL, and release notes
4. Run TestFlight cycle
   - Follow `TESTFLIGHT_RUNBOOK.md` for upload, internal QA, and blocker triage
5. Submit for App Review
   - Submit build and metadata
   - Monitor reviewer feedback and respond until approved
