# Wordoku Manual QA Checklist

Use this checklist before each TestFlight candidate and before final App Review submission.

Automated evidence snapshot (latest):

- Full suite: `TEST SUCCEEDED` (61 tests, 0 failures)
- xcresult: `/Users/joaquinalmora/Library/Developer/Xcode/DerivedData/wordoku-dbuutxwedkgwrdbqhbjihpgwbscy/Logs/Test/Test-wordoku-2026.02.25_10-10-54--0800.xcresult`

## Test environment matrix

| Scenario | Device/OS | Build | Result | Evidence |
| --- | --- | --- | --- | --- |
| Clean install |  |  |  |  |
| Upgrade from previous build |  |  |  |  |
| Offline launch |  |  |  |  |
| Light mode |  |  |  |  |
| Dark mode |  |  |  |  |

## Core gameplay

| ID | Check | Expected result | Result | Notes/Evidence |
| --- | --- | --- | --- | --- |
| G-01 | Open main menu | No crash; cards render (Daily, Continue, Settings) | PASS (Automated) | `wordokuUITests.testLaunchPerformance` + launch tests in latest xcresult |
| G-02 | Open level select | Shows `Level N` labels (no hidden word leak before completion) | PASS (Automated) | `wordokuUITests.testLevelCardsShowGenericLevelLabelBeforeCompletion` |
| G-03 | Start level 1 | Grid loads; timer starts from saved value or 0 on new run | PASS (Automated) | `wordokuUITests.testTimerPersistsWhenLeavingAndReturningLevel` |
| G-04 | Enter letters | Input renders immediately in selected cell | PASS (Automated) | `wordokuUITests.testDailyChallengeInputRendersImmediately` |
| G-05 | Mistake behavior | Mistake counter increments only on incorrect input | PASS (Automated) | `GameViewModelTests.testMistakeCounterIncrementsForIncorrectEntry` + `...DoesNotIncrementForCorrectEntry` |
| G-06 | Penalty mode on | Each mistake adds +15s | PASS (Automated) | `GameViewModelTests.testPenaltyModeAddsTimeForMistakes` |
| G-07 | Exit mid-level and return | Grid + timer + mistakes are restored | PASS (Automated, timer+state) | `wordokuUITests.testTimerPersistsWhenLeavingAndReturningLevel` |
| G-08 | Complete forced word | Reveal animation appears before word meaning overlay | PENDING (Manual) | Verify animation order visually |
| G-09 | Complete level | Completion popup appears with time and best-time behavior | PENDING (Manual) | Verify popup content and new-best badge visually |

## Daily challenge

| ID | Check | Expected result | Result | Notes/Evidence |
| --- | --- | --- | --- | --- |
| D-01 | Open Daily Challenge from main menu | Challenge opens without freeze/crash | PASS (Automated) | `wordokuUITests.testDailyChallengeInputRendersImmediately` |
| D-02 | Type into daily puzzle | Letter appears immediately (no delayed render) | PASS (Automated) | `wordokuUITests.testDailyChallengeInputRendersImmediately` |
| D-03 | Complete daily puzzle | Completion popup + streak update behave correctly | PENDING (Manual) | Validate end-to-end streak increment in UI |
| D-04 | Reopen daily on same day | Completion state persists for that date | PENDING (Manual) | Re-enter daily challenge and verify complete state |

## Settings and persistence

| ID | Check | Expected result | Result | Notes/Evidence |
| --- | --- | --- | --- | --- |
| S-01 | Toggle Liquid Glass | Card/background visual style updates and persists relaunch | PASS (Automated, persistence) | `wordokuUITests.testSettingsPersistForLiquidGlass` |
| S-02 | Toggle show conflicts in Settings | Conflict highlights appear/disappear in gameplay and daily challenge | PENDING (Manual) | Validate setting controls conflicts visualization in both modes |
| S-03 | Toggle show mistakes | Mistake display hides/shows in game views | PENDING (Manual) | Confirm toggle effect in both normal + daily game screens |
| S-04 | Toggle penalty mode | Penalty behavior updates in game and daily challenge | PASS (Automated core), PENDING (Manual daily UI) | `GameViewModelTests.testPenaltyModeAddsTimeForMistakes` + manual daily verification |
| S-05 | Reset all progress | Confirmation works; progress resets; app remains stable | PENDING (Manual) | Use Settings reset flow and verify cleared progress |

## Accessibility and UX checks

| ID | Check | Expected result | Result | Notes/Evidence |
| --- | --- | --- | --- | --- |
| A-01 | Dynamic Type (at least one larger size) | Layout remains usable; no clipped critical controls | PENDING (Manual) | Run on-device or simulator Accessibility sizes |
| A-02 | VoiceOver focus pass | Main actions and cells are reachable and understandable | PENDING (Manual) | Run VoiceOver navigation pass |
| A-03 | Orientation changes | No crash; layout remains usable on supported orientations | PASS (Automated launch smoke), PENDING (Manual gameplay layout) | `wordokuUITestsLaunchTests` covers portrait/landscape launch |

## Release sign-off

| Gate | Owner | Status |
| --- | --- | --- |
| Manual QA checklist complete |  | In progress (automation complete; manual rows pending) |
| No P0/P1 defects open |  | Not yet signed off |
| Any known issues documented in release notes |  | Pending after manual QA |
