# Wordoku TestFlight and Submission Runbook

## 1) Pre-upload gates

Complete these before uploading any build:

1. Automated tests pass (latest known good run: 61 tests, 0 failures)
2. Manual QA checklist completed: `MANUAL_QA_CHECKLIST.md`
3. App metadata and privacy answers updated: `APP_STORE_CONNECT_TEMPLATE.md`
4. Release archive builds successfully

## 2) Build and archive

Reference commands:

```bash
xcodebuild -project "wordoku/wordoku.xcodeproj" -scheme "wordoku" -destination "platform=iOS Simulator,name=iPhone 17" test -parallel-testing-enabled NO
xcodebuild archive -project "wordoku/wordoku.xcodeproj" -scheme "wordoku" -configuration Release -destination "generic/platform=iOS" -archivePath "build/wordoku.xcarchive"
```

## 3) Upload to App Store Connect

In Xcode Organizer:

1. Open archive
2. Validate App
3. Distribute App -> App Store Connect -> Upload

Record uploaded build details:

| Field | Value |
| --- | --- |
| Version (`MARKETING_VERSION`) |  |
| Build (`CURRENT_PROJECT_VERSION`) |  |
| Upload date |  |
| Uploaded by |  |

## 4) Internal TestFlight QA pass

Run on at least one current iPhone and one iPad profile if applicable.

| Area | Owner | Status | Notes |
| --- | --- | --- | --- |
| Install + launch |  |  |  |
| Core gameplay |  |  |  |
| Daily challenge |  |  |  |
| Settings persistence |  |  |  |
| Regression sweep |  |  |  |

Any blocker (crash, data loss, progression break) => reject build and fix before submission.

## 5) Submit for review

1. Select build in App Store Connect
2. Fill all missing metadata and compliance sections
3. Add review notes (if useful for reviewer navigation)
4. Submit for review

Track review lifecycle:

| State | Date | Notes |
| --- | --- | --- |
| Waiting for Review |  |  |
| In Review |  |  |
| Rejected/Approved |  |  |

## 6) Rejection handling playbook

If rejected:

1. Copy rejection text verbatim into issue tracker/doc
2. Reproduce locally
3. Patch + retest (automated + manual)
4. Upload new build with incremented `CURRENT_PROJECT_VERSION`
5. Respond clearly in Resolution Center with exact fix notes
