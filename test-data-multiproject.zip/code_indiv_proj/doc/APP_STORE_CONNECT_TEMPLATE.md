# Wordoku App Store Connect Template

Use this as the source of truth for App Store metadata and privacy form entries.

## Product metadata

| Field | Value to submit |
| --- | --- |
| App Name | Wordoku |
| Subtitle |  |
| Primary Category |  |
| Secondary Category |  |
| Keywords (comma-separated) |  |
| Promotional Text |  |
| Description |  |
| What's New in This Version |  |
| Support URL |  |
| Marketing URL (optional) |  |
| Privacy Policy URL |  |
| Copyright |  |

## Age rating questionnaire prep

Set each category based on real app behavior:

- Gambling/Contests: likely `None`
- Medical/Treatment: likely `None`
- Mature/Sexual themes: likely `None`
- User-generated content/chat/social: likely `None`
- Unrestricted web access: likely `No`

Final values must be selected in App Store Connect UI.

## Privacy details template (App Privacy section)

Code audit status in this repo:

- No networking calls detected in app runtime code.
- No ad SDK usage detected.
- No location/camera/microphone/contacts/photos APIs detected.
- Uses `UserDefaults` for local settings/progress persistence.

Recommended App Privacy responses (confirm before submit):

| Prompt | Suggested answer |
| --- | --- |
| Do you collect data from this app? | No (if still no backend/analytics/crash SDK at release) |
| Is data used to track users? | No |
| Third-party data sharing | No |

If you add analytics/crash reporting/backend before launch, this section must be updated.

## Privacy Manifest alignment

Manifest file: `wordoku/wordoku/PrivacyInfo.xcprivacy`

Current declared required-reason API:

- `NSPrivacyAccessedAPICategoryUserDefaults` with reason `CA92.1`

Verification checklist:

| Check | Status |
| --- | --- |
| Manifest included in app bundle | Done |
| Required-reason API list matches code usage | Done (UserDefaults only) |
| No undeclared required-reason APIs found | Done |

## Localization assets checklist

| Asset type | Required locales | Status |
| --- | --- | --- |
| App Name/Subtitles |  |  |
| Description |  |  |
| Keywords |  |  |
| Screenshots |  |  |
| What's New |  |  |
